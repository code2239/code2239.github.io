import { defineConfig } from 'vite';
export default defineConfig(({mode})=>({ server: { host: '127.0.0.1', hmr: { host: '127.0.0.1', port: 4318 } }, build: { sourcemap: mode!=='showcase' } }));
