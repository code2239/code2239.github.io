import assert from 'node:assert/strict';
import { unzipSync, strFromU8 } from 'fflate';

const base=process.env.QA_URL||'http://127.0.0.1:4319';
if(!base.endsWith(':4319'))throw new Error('只对隔离的 4319 QA 实例运行此脚本。');
async function request(route,input,expected=200){const res=await fetch(base+'/api/'+route,input?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(input)}:{});const data=await res.json();assert.equal(res.status,expected,JSON.stringify(data));return data;}
let s=await request('state');
s=await request('reset',{revision:s.project.revision});
const initial=s.project.revision;
s=await request('project',{revision:initial,actions:[{type:'set_dos',value:true}],label:'QA 添加 DOS'});
assert.equal(s.project.includeDos,true);assert.equal(s.cost.items.length,4);
await request('project',{revision:initial,actions:[{type:'set_dos',value:false}]},400);
await request('project',{revision:s.project.revision,actions:[{type:'set_setting',key:'cores',value:-1}]},400);
s=await request('undo',{revision:s.project.revision});assert.equal(s.project.includeDos,false);
const exported=await fetch(base+'/api/export');assert.equal(exported.status,200);const zip=unzipSync(new Uint8Array(await exported.arrayBuffer()));assert.equal(JSON.parse(strFromU8(zip['workflow.json'])).revision,s.project.revision);
await request('config',{engine:'demo'});
const chat=await fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:'加入 DOS 分支'})});
const events=await chat.text();const result=JSON.parse(events.match(/event: result\ndata: (.+)/)[1]);assert.equal(result.source,'demo');assert.equal(result.actions[0].type,'set_dos');
s=await request('project',{revision:result.revision,actions:result.actions,label:'QA 应用助手修改'});assert.equal(s.project.includeDos,true);
await request('replay',{revision:s.project.revision,scenario:'success'});
await request('replay',{revision:s.project.revision},400);
await new Promise(r=>setTimeout(r,7000));s=await request('state');assert.equal(s.runs[0].status,'completed');assert.ok(s.runs[0].completed.includes('dos'));
await request('replay',{revision:s.project.revision,scenario:'scf-error'});await new Promise(r=>setTimeout(r,4900));s=await request('state');assert.equal(s.runs[0].status,'failed');assert.ok(!s.runs[0].completed.includes('bands'));
const skill=s.skills[0];s=await request('skills',{...skill,enabled:false});assert.equal(s.skills.find(x=>x.id===skill.id).enabled,false);await request('skills',{...skill,enabled:true});
const bad=await fetch(base+'/api/project',{method:'POST',headers:{'Content-Type':'application/json','Origin':'https://unrelated.example'},body:'{}'});assert.equal(bad.status,403);
console.log('PASS: API persistence, version conflicts, atomic validation, export, assistant proposals, success/failure playback, Skill toggles and origin rejection.');
