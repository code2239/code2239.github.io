import test from 'node:test';
import assert from 'node:assert/strict';
import { defaultProject, estimate, applyActions, parseStructure, SI_POSCAR, validateSkill, builtinSkills, ruleReply } from '../server/core.mjs';
import { exportFiles, exportZip } from '../server/export.mjs';
import { unzipSync, strFromU8 } from 'fflate';

test('manual estimate counts allocated core hours once, excluding queue',()=>{
  const project=defaultProject();project.settings={...project.settings,cores:64,rate:.05,hours:{relax:2,scf:1,bands:.5,dos:.75}};
  const cost=estimate(project);assert.equal(cost.coreHours,224);assert.equal(cost.cost,11.200000000000001);assert.equal(cost.computeHours,3.5);assert.equal(cost.queueHours,null);
});
test('DOS branch charges all jobs but elapsed estimate follows critical path',()=>{
  const p=defaultProject();p.includeDos=true;p.settings.hours={relax:2,scf:1,bands:.5,dos:.75};p.settings.cores=64;p.settings.rate=.05;
  const c=estimate(p);assert.equal(c.items.length,4);assert.equal(c.coreHours,272);assert.equal(c.computeHours,3.75);assert.equal(c.cost,13.600000000000001);
});
test('stale agent patches and invalid settings cannot alter a project',()=>{
  const p=defaultProject();assert.throws(()=>applyActions(p,[{type:'set_dos',value:true}],0),/最新版本/);
  for(const value of [NaN,Infinity,-1,1.5,513,'64'])assert.throws(()=>applyActions(p,[{type:'set_setting',key:'cores',value}],1));
  assert.throws(()=>applyActions(p,[{type:'arbitrary_shell',value:'bad'}],1));assert.equal(p.includeDos,false);
});
test('compound patches are atomic when a later action fails',()=>{
  const p=defaultProject();assert.throws(()=>applyActions(p,[{type:'set_dos',value:true},{type:'set_setting',key:'cores',value:-2}],1));assert.equal(p.includeDos,false);assert.equal(p.revision,1);
});
test('VASP5 structure import validates cell and all coordinates',()=>{
  const s=parseStructure(SI_POSCAR,'POSCAR');assert.equal(s.atoms,2);assert.deepEqual(s.species,['Si']);
  assert.throws(()=>parseStructure(SI_POSCAR.replace('0.250000 0.250000 0.250000','NaN 0 0')),/坐标/);
  assert.throws(()=>parseStructure(SI_POSCAR.replace('0.000000 2.715000 2.715000','0 0 0')),/晶格/);
});
test('CIF import refuses unexpanded non-P1 symmetry and partial occupancy',()=>{
  assert.throws(()=>parseStructure('data_example\n_space_group_IT_number 227\n','silicon.cif'),/P1/);
  const cif=`data_test\n_space_group_IT_number 1\n_cell_length_a 5\n_cell_length_b 5\n_cell_length_c 5\n_cell_angle_alpha 90\n_cell_angle_beta 90\n_cell_angle_gamma 90\nloop_\n_atom_site_type_symbol\n_atom_site_fract_x\n_atom_site_fract_y\n_atom_site_fract_z\n_atom_site_occupancy\nSi 0 0 0 1\n`;
  assert.equal(parseStructure(cif,'sample.cif').atoms,1);assert.throws(()=>parseStructure(cif.replace('Si 0 0 0 1','Si 0 0 0 0.5'),'sample.cif'),/部分占位/);
});
test('SKILL.md requires named metadata, and never executes a script',()=>{
  assert.equal(validateSkill(builtinSkills[0]).enabled,true);assert.throws(()=>validateSkill({name:'bad',content:'run anything'}),/元数据/);
});
test('demo assistant proposals stay within the application action vocabulary',()=>{
  const p=defaultProject();const reply=ruleReply('加入 DOS，预算不超过 20 元，改为 64 核',p);
  const next=applyActions(p,reply.actions,1);assert.equal(next.includeDos,true);assert.equal(next.settings.budget,20);assert.equal(next.settings.cores,64);
  assert.equal(ruleReply('解释态密度是什么',p).actions.length,0);
});
test('export includes runtime dependency binding and omits licensed POTCAR',()=>{
  const files=exportFiles(defaultProject());assert.ok(files['run_workflow.py'].includes('previous / "CHGCAR"'));assert.ok(files['run_workflow.py'].includes('result.converged_electronic'));
  const zip=unzipSync(exportZip(defaultProject()));for(const name of ['workflow.json','structure.vasp','run_workflow.py','assemble_potcar.py','requirements.txt'])assert.ok(zip[name],`missing ${name}`);assert.equal(zip['POTCAR'],undefined);assert.ok(strFromU8(zip['README.md']).includes('没有运行 VASP'));assert.ok(strFromU8(zip['potcar.spec']).includes('Si'));
});
