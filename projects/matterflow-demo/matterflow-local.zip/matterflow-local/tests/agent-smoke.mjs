const base='http://127.0.0.1:4319';
const config=await fetch(base+'/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({engine:'codex'})});
if(!config.ok)throw new Error('无法切换 QA 引擎');
const started=Date.now();
try{
  const res=await fetch(base+'/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:'请用一句通俗中文解释当前 Si 能带流程。不要修改方案，actions 为空。'}),signal:AbortSignal.timeout(170000)});
  const text=await res.text();
  const result=text.match(/event: result\ndata: (.+)/);
  if(!result)throw new Error(text.slice(-3000));
  const parsed=JSON.parse(result[1]);
  if(parsed.source!=='codex'||!parsed.text||parsed.actions.length)throw new Error('真实引擎响应未通过检查');
  console.log(JSON.stringify({status:'PASS',engine:parsed.source,seconds:Math.round((Date.now()-started)/1000),reply:parsed.text,usage:parsed.usage},null,2));
}finally{
  await fetch(base+'/api/config',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({engine:'demo'})});
}
