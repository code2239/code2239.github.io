import test from 'node:test';
import assert from 'node:assert/strict';
import {demoPlan,workflowOf,validateWorkflow} from '../server/workflow.mjs';
import {defaultProject,estimate,applyActions} from '../server/core.mjs';
import {exportFiles} from '../server/export.mjs';

const task=(id,kind,dependsOn=[],estimatedHours=null)=>({id,kind,title:id,description:'test',dependsOn,estimatedHours});
test('relaxation-only and fixed-structure single point generate different minimal DAGs',()=>{
  assert.deepEqual(demoPlan('只优化结构').tasks.map(t=>t.kind),['relax']);
  assert.deepEqual(demoPlan('固定结构，计算单点能').tasks.map(t=>t.kind),['scf']);
  assert.deepEqual(demoPlan('计算单点能').tasks.map(t=>t.kind),['scf']);
});
test('bands and DOS share SCF, and no invented timing is returned',()=>{
  const w=demoPlan('先优化结构，再计算能带和态密度');
  assert.deepEqual(w.tasks.map(t=>t.kind),['relax','scf','bands','dos']);
  assert.deepEqual(w.tasks.find(t=>t.kind==='dos').dependsOn,['scf']);
  assert.ok(w.tasks.every(t=>t.estimatedHours===null));
});
test('unsupported professional requirements remain visible draft steps',()=>{
  const w=demoPlan('设计声子和弹性常数计算方案');assert.equal(w.tasks.filter(t=>t.kind==='custom').length,2);assert.ok(w.questions.length);
  const p={...defaultProject(),workflow:w};const files=exportFiles(p);assert.equal(JSON.parse(files['execution-readiness.json']).executable,false);
  const legacy={...defaultProject(),goal:'计算磁性结果'};
  assert.ok(workflowOf(legacy).questions.length);
  assert.equal(JSON.parse(exportFiles(legacy)['execution-readiness.json']).executable,false);
});
test('graph rejects cycles, duplicate ids and bands without direct SCF',()=>{
  assert.throws(()=>validateWorkflow({tasks:[task('a','relax',['b']),task('b','scf',['a'])]}),/循环/);
  assert.throws(()=>validateWorkflow({tasks:[task('a','relax'),task('a','scf')]}),/重复/);
  assert.throws(()=>validateWorkflow({tasks:[task('a','relax'),task('b','bands',['a'])]}),/SCF/);
  assert.throws(()=>validateWorkflow({tasks:[task('../bad','scf')]}),/无效/);
});
test('unordered model output is sorted by dependencies',()=>{
  const w=validateWorkflow({tasks:[task('b','bands',['s']),task('s','scf',['r']),task('r','relax')]});assert.deepEqual(w.tasks.map(t=>t.id),['r','s','b']);
});
test('general DAG estimates account for independent roots and parallel branches',()=>{
  const p={...defaultProject(),workflow:validateWorkflow({tasks:[task('a','relax',[],2),task('b','scf',[],4),task('c','scf',['a'],1),task('d','bands',['b'],2)]})};
  const c=estimate(p);assert.equal(c.computeHours,6);assert.equal(c.coreHours,9*32);
});
test('partial estimates are visibly incomplete and never represented as a full free quote',()=>{
  const p={...defaultProject(),workflow:demoPlan('只优化结构')};assert.equal(estimate(p).complete,false);assert.equal(estimate(p).unknownCount,1);assert.equal(estimate(p).computeHours,null);
});
test('task edits change real dependencies and preserve immutable originals',()=>{
  const p={...defaultProject(),workflow:demoPlan('计算能带')};
  const next=applyActions(p,[{type:'edit_task',id:'scf',value:{dependsOn:[],title:'固定结构静态计算',estimatedHours:1}}],1);
  assert.deepEqual(next.workflow.tasks.find(t=>t.id==='scf').dependsOn,[]);assert.equal(estimate(next).items.find(t=>t.id==='scf').hours,1);assert.deepEqual(p.workflow.tasks.find(t=>t.id==='scf').dependsOn,['relax']);
});
test('remove with downstream is explicit, while removing required dependencies is rejected',()=>{
  const p={...defaultProject(),workflow:demoPlan('能带和态密度')};
  assert.throws(()=>applyActions(p,[{type:'remove_task',id:'scf'}],1),/下游/);
  const next=applyActions(p,[{type:'remove_task',id:'scf',cascade:true}],1);assert.deepEqual(next.workflow.tasks.map(t=>t.kind),['relax']);
});
test('single-point export contains only selected root inputs and an explicit workflow',()=>{
  const p={...defaultProject(),workflow:demoPlan('固定结构计算单点能')};const files=exportFiles(p);assert.ok(files['inputs/scf/POSCAR']);assert.equal(files['inputs/relax/POSCAR'],undefined);assert.equal(JSON.parse(files['workflow.json']).workflow.tasks.length,1);
});
