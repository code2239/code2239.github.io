"""Validate the generated input files with pymatgen, without any VASP run or PAW data."""
import importlib.util
from pathlib import Path
import sys

directory = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(directory))
from pymatgen.core import Structure
from pymatgen.io.vasp import Incar, Kpoints, Poscar

spec = importlib.util.spec_from_file_location("exported_workflow", directory / "run_workflow.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
structure = Structure.from_file(directory / "structure.vasp")
module.checked_path(structure)

# PAW files are intentionally unavailable. Replace only the assembly boundary in this test.
module.assemble = lambda target, symbols: Path(target).write_text("TEST PLACEHOLDER — NOT A POTENTIAL\n")
relax = module.prepare("relax", structure)
assert len(Poscar.from_file(relax / "POSCAR").structure) == 2
assert Incar.from_file(relax / "INCAR")["NSW"] == 150
assert Kpoints.from_file(relax / "KPOINTS").kpts[0] == (8, 8, 8)
scf = module.prepare("scf", structure)
try:
    module.prepare("bands", structure, scf)
    raise AssertionError("Missing CHGCAR must reject the bands step")
except RuntimeError as error:
    assert "CHGCAR" in str(error)
(scf / "CHGCAR").write_text("UPSTREAM TEST MARKER")
bands = module.prepare("bands", structure, scf)
assert Incar.from_file(bands / "INCAR")["ICHARG"] == 11
assert Kpoints.from_file(bands / "KPOINTS").num_kpts > 10
assert (bands / "CHGCAR").read_text() == "UPSTREAM TEST MARKER"
dos = module.prepare("dos", structure, scf)
assert Kpoints.from_file(dos / "KPOINTS").kpts[0] == (12, 12, 12)
try:
    module.checked_path(structure * [2, 1, 1])
    raise AssertionError("Non-standard supercell must not silently use primitive path coordinates")
except RuntimeError as error:
    assert "原胞" in str(error)
for filename in ["POSCAR", "INCAR", "KPOINTS"]:
    assert (directory / "inputs" / "relax" / filename).is_file()
assert len(Poscar.from_file(directory / "inputs" / "relax" / "POSCAR").structure) == 2
assert Incar.from_file(directory / "inputs" / "relax" / "INCAR")["ENCUT"] == 520
print("PASS: pymatgen read/write, SCF dependencies, path-cell consistency, DOS mesh, exported initial inputs. No VASP or licensed potentials used.")
