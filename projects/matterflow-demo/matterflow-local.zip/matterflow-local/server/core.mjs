import { workflowOf, validateWorkflow, editWorkflow } from './workflow.mjs';
export const SI_POSCAR = `Si primitive cell — MatterFlow sample
1.0
0.000000 2.715000 2.715000
2.715000 0.000000 2.715000
2.715000 2.715000 0.000000
Si
2
Direct
0.000000 0.000000 0.000000
0.250000 0.250000 0.250000
`;

export function defaultProject() {
  return {
    revision: 1, name: '硅的电子能带', goal: '计算硅的常规 PBE 能带，了解电子结构。',
    structure: { name: 'Si · 金刚石结构', formula: 'Si', atoms: 2, species: ['Si'], format: 'poscar', text: SI_POSCAR, builtin: true },
    includeDos: false,
    settings: { cores: 32, rate: 0.08, budget: 50, encut: 520, kmesh: 8, hours: { relax: 0.8, scf: 0.35, bands: 0.2, dos: 0.3 } },
    positions: {},
  };
}

export const taskNames = { relax: '优化结构', scf: '计算电子分布', bands: '生成能带', dos: '生成态密度' };
export function estimate(project) {
  const { hours, cores, rate, budget } = project.settings;
  const workflow=validateWorkflow(workflowOf(project));const finish=new Map();
  const items=workflow.tasks.map(t=>({id:t.id,kind:t.kind,name:t.title,hours:t.estimatedHours,known:t.estimatedHours!==null,coreHours:(t.estimatedHours||0)*cores,cost:(t.estimatedHours||0)*cores*rate}));
  for(const t of workflow.tasks)finish.set(t.id,Math.max(0,...t.dependsOn.map(id=>finish.get(id)))+(t.estimatedHours||0));
  const unknownCount=items.filter(t=>!t.known).length;
  const computeHours=unknownCount?null:Math.max(...finish.values());
  const coreHours = items.reduce((sum, item) => sum + item.coreHours, 0);
  const cost = coreHours * rate;
  return { items, computeHours, coreHours, cost, budget, overBudget: cost > budget, low: cost * 0.75, high: cost * 1.5, source: unknownCount?'部分任务待估算':'人工填写 / 示例估算', queueHours: null, parallel: project.includeDos,complete:!unknownCount,unknownCount };
}

export function checks(project) {
  return [
    { label: '结构与步骤依赖', status: 'pass', detail: `${project.structure.atoms} 个原子；后续结构和电荷密度将在运行时传递。` },
    { label:'计算协议与执行器',status:workflowOf(project).tasks.some(t=>t.kind==='custom')||workflowOf(project).questions.length?'warn':'pass',detail:workflowOf(project).tasks.some(t=>t.kind==='custom')?'包含尚未接入的专业步骤；可继续编排，但不能作为完整 VASP 计算执行。':workflowOf(project).questions.join('；')||'任务均可映射到常规 PBE 输入模板；不代表数值精度已验证。' },
    { label: '预算范围', status: estimate(project).high > project.settings.budget ? 'warn' : 'pass', detail: '按分配核时估算；区间为经验范围，排队时间与 Agent 费用未计入。' },
    { label: '数值收敛', status: 'pending', detail: '尚未真实计算；需针对材料验证截断能和 k 点收敛。' },
    { label: 'VASP 与势库', status: 'pending', detail: '未连接 VASP；导出后需在用户授权环境组装 POTCAR。' },
  ];
}

function bounded(value, min, max, label, integer = false) {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value))) throw new Error(`${label}需为 ${min}–${max} 范围内的${integer ? '整数' : '数字'}。`);
  return value;
}

export function applyActions(project, actions, revision) {
  if (revision !== project.revision) throw new Error('方案已更新，请基于最新版本重新操作。');
  if (!Array.isArray(actions) || !actions.length || actions.length > 8) throw new Error('修改内容为空或过多。');
  const next = structuredClone(project);
  for (const action of actions) {
    switch (action.type) {
      case 'set_dos':
        if (typeof action.value !== 'boolean') throw new Error('DOS 设置必须为布尔值。');
        if(next.workflow){
          const w=workflowOf(next);
          if(action.value&&!w.tasks.some(t=>t.kind==='dos')){let scf=w.tasks.find(t=>t.kind==='scf');if(!scf){scf={id:'scf',kind:'scf',title:taskNames.scf,description:'计算自洽电荷密度。',dependsOn:w.tasks.filter(t=>t.kind==='relax').slice(-1).map(t=>t.id),estimatedHours:null};w.tasks.push(scf);}let id='dos';while(w.tasks.some(t=>t.id===id))id+='-new';w.tasks.push({id,kind:'dos',title:taskNames.dos,description:'均匀网格态密度计算。',dependsOn:[scf.id],estimatedHours:null});}
          if(!action.value){const ids=new Set(w.tasks.filter(t=>t.kind==='dos').map(t=>t.id));if(w.tasks.some(t=>!ids.has(t.id)&&t.dependsOn.some(id=>ids.has(id))))throw new Error('DOS 存在下游依赖，请先调整后再移除。');w.tasks=w.tasks.filter(t=>!ids.has(t.id));}
          next.workflow=validateWorkflow(w);
        }
        next.includeDos = action.value; break;
      case 'set_setting': {
        const ranges = { cores: [1, 512, '核数', true], rate: [0, 100, '单价'], budget: [0, 1e7, '预算'], encut: [200, 1500, '截断能', true], kmesh: [1, 40, 'k 点网格', true] };
        const range = ranges[action.key];
        if (!range) throw new Error('不支持的参数。');
        next.settings[action.key] = bounded(action.value, ...range); break;
      }
      case 'set_hours':
        if (!workflowOf(next).tasks.some(t=>t.id===action.key)) throw new Error('未知计算步骤。');
        next.settings.hours[action.key] = bounded(action.value, 0.001, 10000, '运行小时');
        if(next.workflow)next.workflow.tasks.find(t=>t.id===action.key).estimatedHours=action.value;
        break;
      case 'set_workflow':case 'add_task':case 'remove_task':case 'set_dependency':case 'edit_task':
        editWorkflow(next,action);next.positions={};break;
      case 'set_goal':
        if (typeof action.value !== 'string' || !action.value.trim() || action.value.length > 2000) throw new Error('请输入 1–2000 字的计算目标。');
        next.goal = action.value.trim(); break;
      case 'set_structure':
        next.structure = parseStructure(action.text, action.name);
        next.name = `${next.structure.formula} 的电子能带`;
        next.positions = {}; break;
      case 'set_position':
        if (!['structure', ...workflowOf(next).tasks.map(t=>t.id)].includes(action.id) || !action.value || !Number.isFinite(action.value.x) || !Number.isFinite(action.value.y) || Math.abs(action.value.x) > 10000 || Math.abs(action.value.y) > 10000) throw new Error('节点位置无效。');
        next.positions[action.id] = { x: action.value.x, y: action.value.y }; break;
      default: throw new Error('不支持的修改操作。');
    }
  }
  next.revision++;
  return next;
}

function determinant(rows) {
  const [a,b,c] = rows;
  return a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0]);
}

export function parseStructure(text, name = 'POSCAR') {
  if (typeof text !== 'string' || text.length > 500000) throw new Error('结构文件需为小于 500 KB 的文本。');
  const lines = text.trim().split(/\r?\n/).map(l => l.trim());
  if (/^data_/m.test(text) || /\.cif$/i.test(name)) return parseP1Cif(text, name);
  if (lines.length < 9) throw new Error('POSCAR 内容不完整，请上传带元素名称的 VASP 5 格式文件。');
  const scale = Number(lines[1]);
  if (!Number.isFinite(scale) || scale <= 0) throw new Error('本 demo 支持正数缩放系数的 POSCAR，请先转换该结构。');
  const rows = lines.slice(2,5).map(l => l.split(/\s+/).map(Number));
  if (rows.some(row => row.length !== 3 || row.some(v => !Number.isFinite(v))) || Math.abs(determinant(rows)) < 1e-9) throw new Error('晶格向量无效或体积为零。');
  const species = lines[5].split(/\s+/);
  if (species.some(s => !/^[A-Z][a-z]?$/.test(s))) throw new Error('请使用带元素名称的 VASP 5 POSCAR。');
  const counts = lines[6].split(/\s+/).map(Number);
  if (counts.length !== species.length || counts.some(n => !Number.isInteger(n) || n <= 0)) throw new Error('元素与原子数不匹配。');
  const atoms = counts.reduce((a,b)=>a+b,0);
  if (atoms > 1000) throw new Error('演示版最多支持 1000 个原子。');
  let coordinateLine = /^s/i.test(lines[7]) ? 8 : 7;
  if (!/^[dck]/i.test(lines[coordinateLine])) throw new Error('缺少 Direct 或 Cartesian 坐标类型。');
  const coordinates = lines.slice(coordinateLine+1, coordinateLine+1+atoms);
  if (coordinates.length !== atoms || coordinates.some(l => { const xyz=l.split(/\s+/).slice(0,3).map(Number); return xyz.length !== 3 || xyz.some(n=>!Number.isFinite(n)); })) throw new Error('原子坐标不完整或包含非数字。');
  const formula = species.map((s,i)=>`${s}${counts[i]===1?'':counts[i]}`).join('');
  return { name: name.slice(0,100), formula, atoms, species, format: 'poscar', text: text.trim()+'\n', builtin: false };
}

function parseP1Cif(text, name) {
  const scalar = key => { const m = text.match(new RegExp(`^${key}\\s+([^\\s#]+)`, 'mi')); return m?.[1].replace(/["']/g,'').replace(/\([^)]*\)/g,''); };
  const group = scalar('_space_group_IT_number') || scalar('_symmetry_Int_Tables_number');
  const hm = scalar('_space_group_name_H-M_alt') || scalar('_symmetry_space_group_name_H-M');
  if (group !== '1' && !(hm && hm.replace(/\s/g,'') === 'P1')) throw new Error('CIF 导入目前仅支持明确标注的 P1 完整晶胞。其他对称结构请先转换为 POSCAR，以免遗漏对称原子。');
  const a=Number(scalar('_cell_length_a')), b=Number(scalar('_cell_length_b')), c=Number(scalar('_cell_length_c'));
  const alpha=Number(scalar('_cell_angle_alpha'))*Math.PI/180, beta=Number(scalar('_cell_angle_beta'))*Math.PI/180, gamma=Number(scalar('_cell_angle_gamma'))*Math.PI/180;
  if (![a,b,c].every(x=>Number.isFinite(x)&&x>0) || ![alpha,beta,gamma].every(x=>Number.isFinite(x)&&x>0&&x<Math.PI)) throw new Error('CIF 晶胞参数缺失或无效。');
  const rows = text.split(/\r?\n/); let headers=[], data=[];
  for(let i=0;i<rows.length;i++) if(rows[i].trim()==='loop_') {
    let j=i+1,h=[]; while(j<rows.length && rows[j].trim().startsWith('_')) h.push(rows[j++].trim().split(/\s+/)[0]);
    if(h.includes('_atom_site_fract_x')) { headers=h; while(j<rows.length && rows[j].trim() && !/^(_|loop_|data_)/.test(rows[j].trim())) { if(!rows[j].trim().startsWith('#')) data.push(rows[j].trim().split(/\s+/)); j++; } break; }
  }
  const ix=headers.indexOf('_atom_site_fract_x'), iy=headers.indexOf('_atom_site_fract_y'), iz=headers.indexOf('_atom_site_fract_z');
  const elementIndex=headers.includes('_atom_site_type_symbol')?headers.indexOf('_atom_site_type_symbol'):headers.indexOf('_atom_site_label');
  if (ix<0||iy<0||iz<0||elementIndex<0||!data.length) throw new Error('CIF 缺少完整分数坐标。');
  const groups=new Map(); const occ=headers.indexOf('_atom_site_occupancy');
  for(const row of data) {
    if(occ>=0 && Number(row[occ])!==1) throw new Error('不支持部分占位结构，请先构造有序模型。');
    const element=row[elementIndex]?.replace(/["']/g,'').match(/^[A-Z][a-z]?/)?.[0];
    const xyz=[ix,iy,iz].map(i=>Number(row[i]?.replace(/\([^)]*\)/g,'')));
    if(!element||xyz.some(x=>!Number.isFinite(x))) throw new Error('CIF 坐标或元素无法解析。');
    if(!groups.has(element)) groups.set(element,[]); groups.get(element).push(xyz);
  }
  const cx=c*Math.cos(beta), cy=c*(Math.cos(alpha)-Math.cos(beta)*Math.cos(gamma))/Math.sin(gamma), cz2=c*c-cx*cx-cy*cy;
  if(cz2<=0) throw new Error('CIF 晶胞角度不构成有效晶胞。');
  const lattice=[[a,0,0],[b*Math.cos(gamma),b*Math.sin(gamma),0],[cx,cy,Math.sqrt(cz2)]];
  const poscar=`${name}\n1.0\n${lattice.map(r=>r.join(' ')).join('\n')}\n${[...groups.keys()].join(' ')}\n${[...groups.values()].map(r=>r.length).join(' ')}\nDirect\n${[...groups.values()].flat().map(r=>r.join(' ')).join('\n')}\n`;
  return { ...parseStructure(poscar, name.replace(/\.cif$/i,'.vasp')), name, sourceFormat: 'cif' };
}

export const builtinSkills = [
  { id:'vasp-bands', name:'常规能带计算', description:'非磁性周期体系的 PBE 能带流程与输入检查。', version:'1.0.0', enabled:true, content:`---\nname: vasp-bands\ndescription: 为常规非磁性周期体系规划 PBE 弛豫、自洽和高对称路径能带。\n---\n先确认结构与目标。弛豫后使用最终结构。SCF 使用均匀网格，路径能带读取同一结构的 CHGCAR。DOS 是独立均匀网格分支。不要将 HSE、SOC 或磁性任务当作本模板已支持。所有未运行的结果须标明未验证。` },
  { id:'cost-review', name:'计算成本核算', description:'区分运行时间、排队时间和分配核时，解释费用来源。', version:'1.0.0', enabled:true, content:`---\nname: cost-review\ndescription: 解释材料计算工作流的时间、资源和预算。\n---\n费用必须读取应用核算结果，不编造耗时。分配核时等于核数乘运行小时。并行分支费用累计、运行时间取关键路径。排队未知时明确说明。人工示例估算不是预测模型，经验区间不是 P90。Agent 费用未知时不记作零。` },
  { id:'run-diagnosis', name:'运行诊断', description:'依据日志给出失败原因、恢复建议和预算影响。', version:'1.0.0', enabled:true, content:`---\nname: run-diagnosis\ndescription: 阅读实际日志并给出有依据的计算恢复建议。\n---\n引用真实错误证据；没有日志时不得声称已完成诊断。模拟回放不是 VASP 实测。进程结束不代表数值收敛。重试可能产生费用，修改协议需说明对下游的影响。` },
];

export function validateSkill(input) {
  if (!input || typeof input.name!=='string' || !input.name.trim() || input.name.length>60 || typeof input.content!=='string' || input.content.length>30000 || !/^---\s*\n[\s\S]*?\n---/.test(input.content) || !/^name:\s*\S+/m.test(input.content) || !/^description:\s*\S+/m.test(input.content)) throw new Error('技能需包含名称，以及带 name、description 的 SKILL.md 元数据；内容最多 30 KB。');
  return { name: input.name.trim(), description: String(input.description||'自定义专业技能').slice(0,200), version: String(input.version||'1.0.0').slice(0,30), content: input.content, enabled: !!input.enabled };
}

export function ruleReply(message, project, nodeId) {
  const text=message.trim(); let actions=[];
  if(/(加|增加|添加|补|顺便|也|需要|计算|生成|看看).*(DOS|态密度)|(DOS|态密度).*(加上|加入)/i.test(text) && !/(不要|不用|取消|移除|删除)/.test(text)) actions.push({type:'set_dos',value:true});
  if(/(取消|移除|删除|不要|不用).*(DOS|态密度)/i.test(text)) actions.push({type:'set_dos',value:false});
  const budget=text.match(/(?:预算|不超过|最多)[^\d]{0,8}(\d+(?:\.\d+)?)\s*(?:元|块|人民币)?/);
  if(budget) actions.push({type:'set_setting',key:'budget',value:Number(budget[1])});
  const cores=text.match(/(?:改成|改为|使用|用|设为)?\s*(\d+)\s*核/);
  if(cores) actions.push({type:'set_setting',key:'cores',value:Number(cores[1])});
  const c=estimate(project);
  const tasks=workflowOf(project).tasks;
  let reply=`当前方案包含：${tasks.map(t=>t.title).join('、')}。连线表示数据依赖，可以点击步骤修改说明、依赖和耗时。`;
  if(actions.length) reply='我整理了下面的方案修改。应用后会同步更新流程和费用；这里调整预算或核数，不代表已经验证计算精度或并行加速。';
  else if(!c.complete&&/费用|预算|成本|便宜|耗时|多久|时间/.test(text)) reply=`当前有 ${c.unknownCount} 个任务尚未填写耗时，不能给出完整报价。已知部分为 ¥${c.cost.toFixed(2)}；可在节点详情填写人工耗时，或先做实际标定。`;
  else if(/费用|预算|成本|便宜|耗时|多久|时间/.test(text)) reply=`按目前填写的人工示例耗时，累计 ${c.coreHours.toFixed(1)} 核时，计算费约 ¥${c.cost.toFixed(2)}。经验费用范围为 ¥${c.low.toFixed(2)}–${c.high.toFixed(2)}，不含排队、Agent 和存储费用。先标定实际耗时，再据此优化资源配置会更可靠。`;
  else if(/失败|报错|日志/.test(text)) reply='当前只有模拟回放，没有真实 VASP 日志。接入实际日志后，可以根据电子收敛、内存或超时证据定位问题；现在不能声称已经诊断真实计算。';
  else if(/DOS|态密度/i.test(text)) reply='态密度统计每个能量附近的电子态，帮助理解能带以外的电子分布。它通常使用均匀 k 点网格，可从 SCF 后分出一个任务，与路径能带共享上游结构和电荷密度。';
  else if(tasks.find(t=>t.id===nodeId)?.kind==='custom')reply='这个步骤属于尚未接入执行器的专业草案。可以继续编辑方法、依赖和验证要求，但当前不能把它作为完整 VASP 计算执行。'+tasks.find(t=>t.id===nodeId).description;
  else if(nodeId==='relax'||/弛豫|优化结构/.test(text)) reply='优化结构就是让原子和晶胞在给定模型下找到更稳定的排列。后面的计算使用优化后的结构，而不是继续使用最初上传的坐标。默认设置需要通过该体系的收敛检查。';
  else if(nodeId==='scf'||/自洽|电子分布/.test(text)) reply='这一步反复更新电子密度，直到输入与计算出的电子分布足够一致。它生成后续能带与 DOS 需要的 CHGCAR。程序结束还需要检查是否真正收敛。';
  else if(nodeId==='bands'||/能带/.test(text)) reply='能带展示电子能量随晶体动量的变化。常规 PBE 路径计算使用前一步的自洽电荷密度，在高对称路径取样。PBE 带隙不应直接当作准确实验带隙。';
  else if(/k点|k 点|网格/i.test(text)) reply='k 点网格描述我们在布里渊区采样的密度。更密通常增加计算工作量；要比较目标性质在不同网格下的变化，才能判断是否足够。当前网格是示例设置，尚未做收敛测试。';
  return { reply, actions, source:'demo', usage:null };
}
