"""Resolve CIF symmetry with pymatgen. Input/output use JSON on stdio."""
import io
import json
import sys
import warnings
from pymatgen.io.cif import CifParser
from pymatgen.io.vasp import Poscar

data = json.load(sys.stdin)
with warnings.catch_warnings(record=True) as notes:
    warnings.simplefilter("always")
    parser = CifParser.from_str(data["text"])
    structures = parser.parse_structures(primitive=False)
    if len(structures) != 1:
        raise ValueError("CIF 包含多个结构，请拆分后选择一个结构。")
    structure = structures[0]
    if not structure.is_ordered:
        raise ValueError("存在部分占位，请先建立有序模型。")
    if len(structure) > 1000:
        raise ValueError("演示版最多支持 1000 个原子。")
    json.dump({"poscar": str(Poscar(structure.get_sorted_structure())),
               "warnings": [str(note.message) for note in notes][:5]}, sys.stdout)
