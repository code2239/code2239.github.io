import { readFileSync } from 'node:fs';
import { zipSync, strToU8 } from 'fflate';
import { exportFiles as buildFiles } from '../shared/export.mjs';

export function exportFiles(project) {
  return buildFiles(project, readFileSync(new URL('../templates/run_workflow.py', import.meta.url), 'utf8'));
}

export function exportZip(project) {
  return zipSync(Object.fromEntries(Object.entries(exportFiles(project)).map(([name,text])=>[name,strToU8(text)])));
}
