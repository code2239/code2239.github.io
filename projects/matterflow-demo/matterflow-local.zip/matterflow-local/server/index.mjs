import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFile, writeFile, mkdir, rename } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { defaultProject, estimate, checks, applyActions, builtinSkills, validateSkill } from './core.mjs';
import { exportZip } from './export.mjs';
import { agentStatus, callAgent, planCalculation } from './agents.mjs';
import { workflowOf, validateWorkflow } from './workflow.mjs';
import { importStructure } from './structure.mjs';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const data=process.env.MATTERFLOW_DATA_DIR?path.resolve(process.env.MATTERFLOW_DATA_DIR):path.join(root,'.data'); await mkdir(data,{recursive:true});
const statePath=path.join(data,'state.json');
let store={project:defaultProject(),history:[],runs:[],messages:[],skills:structuredClone(builtinSkills),config:{engine:'demo'}};
try {store=JSON.parse(await readFile(statePath,'utf8'));} catch(error) {if(error.code!=='ENOENT') throw new Error('项目存档无法读取，请保留 .data/state.json 并检查 JSON。');}
for(const run of store.runs) if(run.status==='running') {run.status='interrupted';run.logs.push('服务已重启，模拟回放已中止；可以重新播放。');}
let writeQueue=Promise.resolve();
function persist() { const serialized=JSON.stringify(store,null,2); writeQueue=writeQueue.then(async()=>{await writeFile(statePath+'.tmp',serialized);await rename(statePath+'.tmp',statePath);}); return writeQueue; }
const snapshot=()=>({...store,project:{...store.project,workflow:workflowOf(store.project)},cost:estimate(store.project),checks:checks(store.project)});
function json(res,status,body) {res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(body));}
async function body(req) {let text='';for await (const chunk of req) {text+=chunk;if(text.length>800000)throw new Error('请求过大。');}try{return JSON.parse(text||'{}');}catch{throw new Error('请求需为合法 JSON。');}}
function commit(actions,revision,label) {
  const next=applyActions(store.project,actions,revision);
  store.history.push({id:randomUUID(),at:new Date().toISOString(),label:label||'更新方案',before:store.project});
  store.history=store.history.slice(-40); store.project=next;
}
let statuses=[],statusAt=0; const active=new Map(),drafts=new Map();

function beginReplay(scenario) {
  if(store.runs.some(r=>r.status==='running'))throw new Error('已有回放正在进行。');
  const cost=estimate(store.project);if(cost.complete&&cost.high>store.project.settings.budget)throw new Error('费用经验上界超过预算，请先调整。');
  const workflow=validateWorkflow(workflowOf(store.project));
  const run={id:randomUUID(),revision:store.project.revision,project:{...structuredClone(store.project),workflow},status:'running',stage:'',activeTasks:[],startedAt:new Date().toISOString(),endedAt:null,scenario,logs:['[模拟回放] 不调用 VASP、不提交集群、不产生 HPC 费用。'],completed:[]};
  const ready=()=>workflow.tasks.filter(t=>!run.completed.includes(t.id)&&t.dependsOn.every(id=>run.completed.includes(id)));
  const setActive=()=>{run.activeTasks=ready().map(t=>t.id);run.stage=run.activeTasks[0]||'complete';};setActive();
  store.runs.unshift(run);store.runs=store.runs.slice(0,20);
  const timer=setInterval(()=>{
    if(run.status!=='running'){clearInterval(timer);return;}
    const tasks=ready();
    if(scenario==='scf-error'&&tasks.some(t=>t.kind==='scf')){run.status='failed';run.endedAt=new Date().toISOString();run.logs.push('[模拟错误] SCF 达到 NELM=120，未收敛；下游已阻止。该日志为演示样本。');}
    else {for(const task of tasks){run.completed.push(task.id);run.logs.push(`[回放] ${task.title} 结束（模拟），输出传递给依赖此步骤的任务。`);}setActive();if(run.completed.length===workflow.tasks.length){run.status='completed';run.endedAt=new Date().toISOString();run.logs.push('[回放] 流程结束；不代表真实计算结果或科学验证通过。');}}
    persist().catch(console.error);if(run.status!=='running')clearInterval(timer);
  },1800);return run;
}

let vite;
if(process.argv.includes('--dev')) {const {createServer}=await import('vite');vite=await createServer({root,server:{middlewareMode:true},appType:'spa'});}

const server=http.createServer(async(req,res)=>{
  try {
    const host=req.headers.host||'';
    if(!/^(127\.0\.0\.1|localhost)(:\d+)?$/.test(host)) return json(res,403,{error:'仅允许本机访问。'});
    if(req.headers.origin && ![`http://${host}`].includes(req.headers.origin)) return json(res,403,{error:'请求来源不匹配。'});
    const url=new URL(req.url,'http://'+host); const route=url.pathname;
    if(route.startsWith('/api/')) {
      if(req.method==='GET'&&route==='/api/state') return json(res,200,snapshot());
      if(req.method==='POST'&&route==='/api/structure'){const input=await body(req);return json(res,200,{structure:await importStructure(input.text,input.name)});}
      if(req.method==='POST'&&route==='/api/plan'){
        const input=await body(req);
        if(typeof input.goal!=='string'||!input.goal.trim()||input.goal.length>2000)throw new Error('请用 1–2000 字描述计算目标。');
        if(input.revision!==store.project.revision)throw new Error('当前方案已改变，请刷新后生成。');
        if(!['demo','codex','claude'].includes(input.engine))throw new Error('请选择规划引擎。');
        if(active.size)throw new Error('助手正在处理其他请求，请等待或停止后重试。');
        const base=structuredClone(store.project);
        const structure=input.useCurrent?base.structure:await importStructure(input.text,input.name);
        if(res.destroyed)return;
        if(active.size)throw new Error('助手正在处理其他请求，请等待或停止后重试。');
        const controller=new AbortController(),id=randomUUID();active.set(id,controller);
        res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache','Connection':'keep-alive'});
        const event=(type,payload)=>{if(!res.destroyed)res.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`);};
        res.on('close',()=>{if(!res.writableEnded)controller.abort();});
        const heartbeat=setInterval(()=>{if(!res.destroyed)res.write(': keepalive\n\n');},10000);
        event('progress',{text:'结构已解析，正在根据目标拆解计算步骤…',id});
        try{
          const plan=await planCalculation({engine:input.engine,goal:input.goal.trim(),structure,skills:structuredClone(store.skills),workspace:path.join(data,'agent-workspace'),signal:controller.signal,onEvent:text=>event('progress',{text,id})});
          if(controller.signal.aborted)throw new Error('已停止生成，当前项目未改变。');
          const actions=[{type:'set_workflow',value:plan.workflow},...Object.entries(plan.settings).filter(([key,v])=>['encut','kmesh','cores','budget'].includes(key)&&v!==null).map(([key,value])=>({type:'set_setting',key,value}))];
          const candidate=applyActions({...base,structure},actions,base.revision);candidate.name=plan.name;candidate.goal=input.goal.trim();candidate.planning={source:plan.source,usage:plan.usage,at:new Date().toISOString(),skills:store.skills.filter(s=>s.enabled).map(s=>({id:s.id,name:s.name,version:s.version}))};
          const token=randomUUID();drafts.set(token,{project:candidate,baseRevision:base.revision,at:Date.now()});for(const [key,draft]of drafts)if(Date.now()-draft.at>1800000)drafts.delete(key);
          event('result',{token,project:candidate,cost:estimate(candidate),checks:checks(candidate)});
        }catch(error){event('error',{error:error.message});}finally{clearInterval(heartbeat);active.delete(id);res.end();}return;
      }
      if(req.method==='POST'&&route==='/api/plan/apply'){
        const input=await body(req),draft=drafts.get(input.token);if(!draft||Date.now()-draft.at>1800000)throw new Error('方案草案已过期，请重新生成。');
        if(draft.baseRevision!==store.project.revision||input.revision!==store.project.revision)throw new Error('生成期间项目已修改，请重新生成，避免覆盖最新方案。');
        store.history.push({id:randomUUID(),at:new Date().toISOString(),label:'采用 Agent 生成的新方案',before:store.project,messages:store.messages});store.history=store.history.slice(-40);
        store.project=draft.project;store.config.engine=store.project.planning.source;
        store.messages=[{id:randomUUID(),role:'assistant',text:store.project.workflow.summary,actions:[],revision:store.project.revision,source:store.config.engine,usage:store.project.planning.usage,skills:store.project.planning.skills,at:new Date().toISOString()}];drafts.delete(input.token);await persist();return json(res,200,snapshot());
      }
      if(req.method==='GET'&&route==='/api/agents') {
        if(Date.now()-statusAt>30000||url.searchParams.has('refresh')) {statuses=await Promise.all(['codex','claude'].map(agentStatus));statusAt=Date.now();}
        return json(res,200,{agents:statuses,claudeApiConfigured:!!process.env.ANTHROPIC_API_KEY});
      }
      if(req.method==='GET'&&route==='/api/export') {
        const zip=exportZip(store.project);
        res.writeHead(200,{'Content-Type':'application/zip','Content-Disposition':`attachment; filename="matterflow-v${store.project.revision}.zip"`});return res.end(zip);
      }
      if(req.method==='POST'&&route==='/api/project') {
        const input=await body(req);commit(input.actions,input.revision,String(input.label||'更新方案').slice(0,100));await persist();return json(res,200,snapshot());
      }
      if(req.method==='POST'&&route==='/api/undo') {
        const input=await body(req);if(input.revision!==store.project.revision)throw new Error('方案版本已改变。');
        const last=store.history.pop();if(!last)throw new Error('没有可以撤销的修改。');
        store.project={...last.before,revision:store.project.revision+1};if(last.messages)store.messages=last.messages;await persist();return json(res,200,snapshot());
      }
      if(req.method==='POST'&&route==='/api/reset') {
        if(store.runs.some(r=>r.status==='running'))throw new Error('请先停止当前回放。');
        const input=await body(req);if(input.revision!==store.project.revision)throw new Error('方案版本已改变。');
        store.history.push({id:randomUUID(),at:new Date().toISOString(),label:'载入硅示例',before:store.project});
        store.project={...defaultProject(),revision:store.project.revision+1};await persist();return json(res,200,snapshot());
      }
      if(req.method==='POST'&&route==='/api/config') {
        const input=await body(req);if(!['demo','codex','claude'].includes(input.engine))throw new Error('无效引擎。');
        store.config.engine=input.engine;await persist();return json(res,200,snapshot());
      }
      if(req.method==='POST'&&route==='/api/skills') {
        const input=await body(req);const skill=validateSkill(input);
        let existing=store.skills.find(s=>s.id===input.id);
        if(existing) {const changed=existing.content!==skill.content; Object.assign(existing,skill);if(changed&&existing.version===input.version)existing.version=`${input.version.split('+')[0]}+${Date.now().toString(36)}`;}
        else {existing={id:randomUUID(),...skill};store.skills.push(existing);}
        const dir=path.join(data,'skills',existing.id);await mkdir(dir,{recursive:true});await writeFile(path.join(dir,'SKILL.md'),existing.content);await persist();return json(res,200,snapshot());
      }
      if(req.method==='POST'&&route==='/api/replay') {const input=await body(req);if(input.revision!==store.project.revision)throw new Error('请基于最新方案开始回放。');beginReplay(input.scenario==='scf-error'?'scf-error':'success');await persist();return json(res,200,snapshot());}
      if(req.method==='POST'&&route==='/api/replay/stop') {const run=store.runs.find(r=>r.status==='running');if(run){run.status='cancelled';run.endedAt=new Date().toISOString();run.logs.push('[回放] 用户停止演示。');}await persist();return json(res,200,snapshot());}
      if(req.method==='POST'&&route==='/api/chat') {
        const input=await body(req);
        if(typeof input.message!=='string'||!input.message.trim()||input.message.length>6000)throw new Error('请输入 1–6000 字的消息。');
        if(active.size)throw new Error('助手正在处理请求，请等待或停止后再发送。');
        const project=structuredClone(store.project), engine=store.config.engine;
        const controller=new AbortController(), id=randomUUID();active.set(id,controller);
        res.writeHead(200,{'Content-Type':'text/event-stream; charset=utf-8','Cache-Control':'no-cache','Connection':'keep-alive','X-Accel-Buffering':'no'});
        const event=(type,payload)=>{if(!res.destroyed)res.write(`event: ${type}\ndata: ${JSON.stringify(payload)}\n\n`);};
        const history=store.messages.slice();const user={id:randomUUID(),role:'user',text:input.message,at:new Date().toISOString(),nodeId:input.nodeId||null};
        store.messages.push(user);
        res.on('close',()=>{if(!res.writableEnded)controller.abort();});
        const heartbeat=setInterval(()=>{if(!res.destroyed)res.write(': keepalive\n\n');},10000);
        event('progress',{text:engine==='demo'?'演示助手正在整理方案…':'正在连接本机 '+engine+'…',id});
        try {
          const result=await callAgent({engine,message:input.message,nodeId:input.nodeId,project,skills:store.skills,history,workspace:path.join(data,'agent-workspace'),signal:controller.signal,onEvent:text=>event('progress',{text,id})});
          if(result.actions.length)applyActions(project,result.actions,project.revision);
          const answer={id:randomUUID(),role:'assistant',text:result.reply,actions:result.actions,revision:project.revision,source:result.source,usage:result.usage,skills:result.skills||store.skills.filter(s=>s.enabled).map(s=>({id:s.id,name:s.name,version:s.version})),at:new Date().toISOString()};
          store.messages.push(answer);store.messages=store.messages.slice(-80);await persist();event('result',answer);
        } catch(error){event('error',{error:error.message});await persist();}
        finally{clearInterval(heartbeat);active.delete(id);res.end();}
        return;
      }
      if(req.method==='POST'&&route==='/api/chat/stop') {for(const c of active.values())c.abort();return json(res,200,{ok:true});}
      return json(res,404,{error:'接口不存在。'});
    }
    if(vite)return vite.middlewares(req,res);
    const publicRoot=path.join(root,'dist');let file=path.resolve(publicRoot,'.'+decodeURIComponent(route));
    if(!file.startsWith(publicRoot+path.sep)&&file!==publicRoot)return json(res,403,{error:'无效路径。'});
    if(!path.extname(file))file=path.join(publicRoot,'index.html');
    const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.json':'application/json','.map':'application/json'};
    try{const content=await readFile(file);res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(content);}catch{res.writeHead(404);res.end('请先 npm run build，或使用 npm run dev。');}
  } catch(error) {if(!res.headersSent)json(res,400,{error:error.message});else res.end();}
});
const port=Number(process.env.PORT||4317);
server.listen(port,'127.0.0.1',()=>console.log(`MatterFlow ready: http://127.0.0.1:${port}`));
server.on('error',error=>{console.error(error.message);process.exitCode=1;});
