export const catalog = {
  relax: { title:'优化结构', description:'找到当前物理模型下更稳定的原子与晶胞排列。' },
  scf: { title:'静态自洽计算', description:'计算总能量与自洽电荷密度。' },
  bands: { title:'生成能带', description:'基于自洽电荷密度沿高对称路径计算。' },
  dos: { title:'生成态密度', description:'基于自洽电荷密度在均匀网格上计算。' },
  custom: { title:'专业计算步骤', description:'待接入专用执行器；当前只规划，不实际执行。' },
};

export function workflowOf(project) {
  const extended=needsExtendedProtocol(project.goal||'');
  const note='目标涉及超出常规非磁性 PBE 的物理协议，需接入对应执行器后才能执行。';
  if(project.workflow) {
    const w=structuredClone(project.workflow);
    if(extended&&!w.questions.includes(note))w.questions.push(note);
    return w;
  }
  return { summary:project.goal, assumptions:['常规非磁性 PBE；参数与数值精度待验证。'], questions:extended?[note]:[], source:'template', tasks:[
    {id:'relax',kind:'relax',title:'优化结构',description:catalog.relax.description,dependsOn:[],estimatedHours:project.settings.hours.relax},
    {id:'scf',kind:'scf',title:'计算电子分布',description:catalog.scf.description,dependsOn:['relax'],estimatedHours:project.settings.hours.scf},
    {id:'bands',kind:'bands',title:'生成能带',description:catalog.bands.description,dependsOn:['scf'],estimatedHours:project.settings.hours.bands},
    ...(project.includeDos?[{id:'dos',kind:'dos',title:'生成态密度',description:catalog.dos.description,dependsOn:['scf'],estimatedHours:project.settings.hours.dos}]:[]),
  ]};
}

export function validateWorkflow(input) {
  if(!input || !Array.isArray(input.tasks) || !input.tasks.length || input.tasks.length>20)throw new Error('方案需包含 1–20 个任务。');
  const tasks=input.tasks.map(t=>{
    if(!t||typeof t.id!=='string'||!/^[a-z][a-z0-9_-]{0,39}$/.test(t.id)||t.id==='structure'||!Object.hasOwn(catalog,t.kind))throw new Error('任务标识或类型无效。');
    if(typeof t.title!=='string'||!t.title.trim()||t.title.length>80||typeof t.description!=='string'||t.description.length>1600||!Array.isArray(t.dependsOn)||t.dependsOn.length>20||t.dependsOn.some(x=>typeof x!=='string'))throw new Error('任务名称、说明或依赖无效。');
    const h=t.estimatedHours??null;
    if(h!==null&&(typeof h!=='number'||!Number.isFinite(h)||h<.001||h>10000))throw new Error('任务耗时应为有效小时数或待估算。');
    return {id:t.id,kind:t.kind,title:t.title.trim(),description:t.description,dependsOn:[...new Set(t.dependsOn)],estimatedHours:h};
  });
  const map=new Map(tasks.map(t=>[t.id,t]));if(map.size!==tasks.length)throw new Error('任务标识不能重复。');
  for(const t of tasks){for(const id of t.dependsOn)if(!map.has(id)||id===t.id)throw new Error('依赖的任务不存在或指向自身。');if(['bands','dos'].includes(t.kind)&&t.dependsOn.filter(id=>map.get(id)?.kind==='scf').length!==1)throw new Error(`${t.title} 必须直接依赖唯一提供电荷密度的 SCF 任务。`);if(['relax','scf'].includes(t.kind)&&t.dependsOn.some(id=>['bands','dos'].includes(map.get(id).kind)))throw new Error('结构或自洽任务不能依赖性质计算的输出。');if(['relax','scf'].includes(t.kind)&&t.dependsOn.length>1)throw new Error('结构来源不唯一，请明确一个结构上游。');}
  const ordered=[],visiting=new Set(),done=new Set();
  const visit=t=>{if(visiting.has(t.id))throw new Error('方案存在循环依赖。');if(done.has(t.id))return;visiting.add(t.id);t.dependsOn.forEach(id=>visit(map.get(id)));visiting.delete(t.id);done.add(t.id);ordered.push(t);};tasks.forEach(visit);
  const strings=(value,max)=>{if(value===undefined)return[];if(!Array.isArray(value)||value.length>max||value.some(x=>typeof x!=='string'||x.length>1600))throw new Error('方案假设或待确认问题无效。');return value;};
  return {summary:String(input.summary||'').slice(0,2000),assumptions:strings(input.assumptions,12),questions:strings(input.questions,12),source:['demo','codex','claude','template','manual'].includes(input.source)?input.source:'manual',tasks:ordered};
}

export function editWorkflow(project,action) {
  let w=workflowOf(project);
  if(action.type==='set_workflow')w=validateWorkflow(action.value);
  if(action.type==='add_task') {
    if(!action.value)throw new Error('缺少任务信息。');
    w.tasks.push(action.value);
  }
  if(action.type==='remove_task') {
    if(!w.tasks.some(t=>t.id===action.id))throw new Error('任务不存在。');
    const removing=new Set([action.id]);let added=true;
    while(added){added=false;for(const t of w.tasks)if(t.dependsOn.some(id=>removing.has(id))&&!removing.has(t.id)){if(!action.cascade)throw new Error('仍有下游依赖，请先调整依赖，或选择连同下游移除。');removing.add(t.id);added=true;}}
    w.tasks=w.tasks.filter(t=>!removing.has(t.id));
  }
  if(action.type==='set_dependency') {
    const task=w.tasks.find(t=>t.id===action.id);if(!task)throw new Error('目标任务不存在。');
    if(typeof action.source!=='string'||typeof action.enabled!=='boolean')throw new Error('连线参数无效。');
    task.dependsOn=action.enabled?[...new Set([...task.dependsOn,action.source])]:task.dependsOn.filter(id=>id!==action.source);
  }
  if(action.type==='edit_task') {
    const task=w.tasks.find(t=>t.id===action.id);if(!task)throw new Error('任务不存在。');
    const {title,description,dependsOn,estimatedHours}=action.value||{};
    Object.assign(task,{...(title!==undefined?{title}:{}),...(description!==undefined?{description}:{}),...(dependsOn!==undefined?{dependsOn}:{}),...(estimatedHours!==undefined?{estimatedHours}:{})});
  }
  project.workflow=validateWorkflow(w);project.includeDos=project.workflow.tasks.some(t=>t.kind==='dos');return project;
}

export function demoPlan(goal) {
  const tasks=[];const add=(id,kind,dependsOn=[])=>tasks.push({id,kind,title:catalog[kind].title,description:catalog[kind].description,dependsOn,estimatedHours:null});
  const skipRelax=/不(?:做|需要|进行)?(?:结构)?(?:优化|弛豫)|跳过(?:结构)?(?:优化|弛豫)|保持.*结构|固定.*结构/.test(goal)||(/单点|静态/.test(goal)&&!/优化|弛豫/.test(goal));
  const onlyStatic=/只(?:做|计算|要)?(?:静态|单点|自洽)/.test(goal);
  const bands=!onlyStatic&&/能带|band/i.test(goal)&&!/不(?:做|计算|需要)?能带|不要.*能带/i.test(goal),dos=!onlyStatic&&/态密度|\bDOS\b/i.test(goal)&&!/不(?:做|计算|需要)?(?:态密度|DOS)|不要.*(?:态密度|DOS)/i.test(goal);
  const custom=[];
  for(const [pattern,id,title]of [[/声子|phonon/i,'phonon','声子计算'],[/弹性|elastic/i,'elastic','弹性常数计算'],[/收敛|convergence/i,'convergence','数值收敛测试'],[/状态方程|\bEOS\b/i,'eos','状态方程计算'],[/缺陷|defect/i,'defect','缺陷模型与能量计算'],[/吸附|adsorp/i,'adsorption','吸附结构与能量计算'],[/\bNEB\b|迁移路径|扩散势垒/i,'neb','迁移路径与势垒计算']])if(pattern.test(goal))custom.push({id,kind:'custom',title,description:'依据研究目标细化协议、参数扫描与后处理；尚未接入专用执行器。',dependsOn:[],estimatedHours:null});
  if(!skipRelax)add('relax','relax');
  if(bands||dos||custom.length||/能量|自洽|单点|SCF|静态/i.test(goal))add('scf','scf',skipRelax?[]:['relax']);
  if(bands)add('bands','bands',['scf']);if(dos)add('dos','dos',['scf']);
  for(const task of custom){task.dependsOn=['scf'];tasks.push(task);}
  const unclear=!bands&&!dos&&!custom.length&&!/优化|弛豫|能量|自洽|单点|SCF|静态/i.test(goal);
  if(unclear){if(!tasks.length)add('scf','scf');tasks.push({id:'research-task',kind:'custom',title:'明确目标性质与计算协议',description:goal,dependsOn:[tasks.at(-1).id],estimatedHours:null});}
  if(!tasks.length)add('relax','relax');
  const advanced=needsExtendedProtocol(goal);
  return validateWorkflow({summary:`根据需求拆解为 ${tasks.length} 个步骤，生成后可编辑节点与依赖。`,assumptions:['人工规则演示，未调用模型。','结构与目标性质需审核；耗时均待人工填写。'],questions:[...(custom.length?['专业计算步骤目前仅为规划草案，需接入并审核执行器。']:[]),...(unclear?['请明确希望得到的性质或结果。']:[]),...(advanced?['该需求涉及扩展物理协议，常规 PBE 执行器不能覆盖；请确认后补充实现。']:[])],source:'demo',tasks});
}

export function needsExtendedProtocol(goal){return /HSE|SOC|磁性|自旋|DFT\s*\+\s*U|杂化|激发态/i.test(goal.replace(/(?:不考虑|忽略|无|非)(?:磁性|自旋)/g,''));}
