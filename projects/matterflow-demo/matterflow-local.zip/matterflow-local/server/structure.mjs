import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { parseStructure } from './core.mjs';

export async function importStructure(text,name='POSCAR'){
  if(typeof text!=='string'||text.length>500000)throw new Error('结构文件需小于 500 KB。');
  try{return parseStructure(text,name);}catch(original){
    if(!/\.cif$/i.test(name)&&!/^data_/m.test(text))throw original;
    const configured=process.env.PYMATGEN_PYTHON;const local=fileURLToPath(new URL('../.venv/bin/python',import.meta.url));
    const python=configured||(existsSync(local)?local:null);
    if(!python)throw new Error(original.message+' 配置 PYMATGEN_PYTHON 或安装 demo/.venv 后可解析一般 CIF。');
    const child=spawn(python,[fileURLToPath(new URL('./import_structure.py',import.meta.url))],{stdio:['pipe','pipe','pipe']});let out='',err='';
    let timedOut=false;const timer=setTimeout(()=>{timedOut=true;child.kill('SIGKILL');},60000);
    child.stdout.on('data',c=>{out+=c.toString();if(out.length>1000000)child.kill('SIGKILL');});child.stderr.on('data',c=>err=(err+c.toString()).slice(-3000));child.stdin.on('error',()=>{});child.stdin.end(JSON.stringify({text,name}));
    try{const code=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',resolve);});if(code!==0)throw new Error(timedOut?'CIF 解析超时，请重试或先转换为 POSCAR。':'CIF 解析失败：'+(err.split('\n').filter(Boolean).at(-1)||'请检查原子占位和晶胞。'));const result=JSON.parse(out);return {...parseStructure(result.poscar,'POSCAR'),name:name.slice(0,100),sourceFormat:'cif',importNotes:result.warnings};}finally{clearTimeout(timer);}
  }
}
