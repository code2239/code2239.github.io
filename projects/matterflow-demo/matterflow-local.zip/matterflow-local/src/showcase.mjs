import {zipSync,strToU8} from 'fflate';
import {defaultProject,estimate,checks,applyActions,builtinSkills,validateSkill,parseStructure,ruleReply} from '../server/core.mjs';
import {workflowOf,validateWorkflow,demoPlan} from '../server/workflow.mjs';
import {exportFiles} from '../shared/export.mjs';
import runTemplate from '../templates/run_workflow.py?raw';

const storageKey='matterflow-showcase-v1';
const makeStore=()=>({project:defaultProject(),history:[],runs:[],messages:[],skills:structuredClone(builtinSkills),config:{engine:'demo'}});
let store=makeStore(),storageError='';
try{const saved=localStorage.getItem(storageKey);if(saved){const value=JSON.parse(saved);validateWorkflow(workflowOf(value.project));store=value;store.config.engine='demo';}}catch{storageError='浏览器存储不可用或存档无效；当前会话仍可使用。';}
for(const run of store.runs)if(run.status==='running'){run.status='interrupted';run.endedAt=new Date().toISOString();}
const drafts=new Map();
const now=()=>new Date().toISOString();
const save=()=>{try{localStorage.setItem(storageKey,JSON.stringify(store));}catch{storageError='浏览器存储空间不足；请先导出方案，当前修改仅保留在此页面。';}};
const snapshot=()=>({...structuredClone(store),project:{...structuredClone(store.project),workflow:workflowOf(store.project)},cost:estimate(store.project),checks:[...checks(store.project),...(storageError?[{label:'浏览器存档',status:'warn',detail:storageError}]:[])]});
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json'}});
const stream=value=>new Response(`event: result\ndata: ${JSON.stringify(value)}\n\n`,{headers:{'Content-Type':'text/event-stream'}});
const revision=value=>{if(value!==store.project.revision)throw new Error('方案已改变，请刷新后再试。');};
const onlyDemo=engine=>{if(engine!=='demo')throw new Error('在线展示版仅提供离线规则演示。请下载本机完整版连接 Codex / Claude Code。');};
function commit(actions,rev,label){
  const project=applyActions(store.project,actions,rev);
  store.history.push({id:crypto.randomUUID(),at:now(),label:label||'调整方案',before:store.project});store.history=store.history.slice(-30);store.project=project;save();
}
function replay(input){
  revision(input.revision);
  if(store.runs.some(r=>r.status==='running'))throw new Error('已有回放正在进行。');
  const cost=estimate(store.project);if(cost.complete&&cost.high>store.project.settings.budget)throw new Error('费用经验上界超过预算，请先调整。');
  const project={...structuredClone(store.project),workflow:validateWorkflow(workflowOf(store.project))};
  const run={id:crypto.randomUUID(),revision:project.revision,project,status:'running',stage:'',activeTasks:[],completed:[],logs:['[模拟回放] 浏览器演示，不调用 VASP，不产生计算费用。'],startedAt:now(),endedAt:null};
  const ready=()=>project.workflow.tasks.filter(t=>!run.completed.includes(t.id)&&t.dependsOn.every(id=>run.completed.includes(id)));
  const activate=()=>{run.activeTasks=ready().map(t=>t.id);run.stage=run.activeTasks[0]||'complete';};activate();store.runs.unshift(run);store.runs=store.runs.slice(0,8);save();
  const timer=setInterval(()=>{
    if(run.status!=='running'){clearInterval(timer);return;}
    const tasks=ready();
    if(input.scenario==='scf-error'&&tasks.some(t=>t.kind==='scf')){run.status='failed';run.logs.push('[模拟错误] SCF 未收敛，阻止下游。这是演示日志。');}
    else{for(const task of tasks){run.completed.push(task.id);run.logs.push(`[回放] ${task.title} 结束（模拟）。`);}activate();if(run.completed.length===project.workflow.tasks.length){run.status='completed';run.logs.push('[回放] 结束；不代表真实计算或科学验证。');}}
    if(run.status!=='running'){run.endedAt=now();clearInterval(timer);}save();
  },1500);
}

export async function browserRequest(input,options={}){
  if(options.signal?.aborted)throw new DOMException('已停止','AbortError');
  const route=input.split('?')[0].replace(/^\/api\//,'');
  try{
    const payload=typeof options.body==='string'?JSON.parse(options.body):{};
    if(route==='state')return json(snapshot());
    if(route==='agents')return json({agents:['codex','claude'].map(engine=>({engine,installed:false,loggedIn:false,version:null,callVerified:false})),claudeApiConfigured:false});
    if(route==='config'){onlyDemo(payload.engine);return json(snapshot());}
    if(route==='project'){commit(payload.actions,payload.revision,payload.label);return json(snapshot());}
    if(route==='undo'){revision(payload.revision);const previous=store.history.pop();if(!previous)throw new Error('没有可撤销的修改。');store.project={...previous.before,revision:store.project.revision+1};if(previous.messages)store.messages=previous.messages;save();return json(snapshot());}
    if(route==='skills'){const validated=validateSkill(payload);const index=store.skills.findIndex(s=>s.id===payload.id);const skill={...validated,id:index<0?crypto.randomUUID():payload.id};if(index<0)store.skills.push(skill);else store.skills[index]=skill;save();return json(snapshot());}
    if(route==='structure')return json({structure:parseStructure(payload.text,payload.name)});
    if(route==='plan'){
      onlyDemo(payload.engine);revision(payload.revision);
      if(typeof payload.goal!=='string'||!payload.goal.trim()||payload.goal.length>2000)throw new Error('请用 1–2000 字描述需求。');
      const structure=payload.useCurrent?store.project.structure:parseStructure(payload.text,payload.name);
      const project=applyActions({...store.project,structure},[{type:'set_workflow',value:demoPlan(payload.goal)}],payload.revision);
      project.name=`${structure.formula} · ${payload.goal.slice(0,24)}`;project.goal=payload.goal.trim();project.planning={source:'demo',usage:null,at:now(),skills:store.skills.filter(s=>s.enabled).map(s=>({id:s.id,name:s.name,version:s.version}))};
      const token=crypto.randomUUID();drafts.set(token,{project,baseRevision:payload.revision,at:Date.now()});
      return stream({token,project,cost:estimate(project),checks:checks(project)});
    }
    if(route==='plan/apply'){
      revision(payload.revision);const draft=drafts.get(payload.token);
      if(!draft||Date.now()-draft.at>1800000)throw new Error('草案已过期，请重新生成。');
      if(draft.baseRevision!==store.project.revision)throw new Error('生成期间方案已改变，请重新生成。');
      store.history.push({id:crypto.randomUUID(),at:now(),label:'采用新方案',before:store.project,messages:store.messages});store.history=store.history.slice(-30);store.project=draft.project;store.messages=[];drafts.delete(payload.token);save();return json(snapshot());
    }
    if(route==='chat'){
      if(typeof payload.message!=='string'||!payload.message.trim()||payload.message.length>6000)throw new Error('请输入 1–6000 字的消息。');
      const result=ruleReply(payload.message,store.project,payload.nodeId);const answer={id:crypto.randomUUID(),role:'assistant',text:result.reply,actions:result.actions,revision:store.project.revision,source:'demo',usage:null,at:now(),skills:[]};
      store.messages.push({id:crypto.randomUUID(),role:'user',text:payload.message,at:now()},answer);store.messages=store.messages.slice(-40);save();return stream(answer);
    }
    if(route==='chat/stop')return json({ok:true});
    if(route==='replay'){replay(payload);return json(snapshot());}
    if(route==='replay/stop'){for(const run of store.runs)if(run.status==='running'){run.status='cancelled';run.endedAt=now();run.logs.push('[模拟回放] 用户停止。');}save();return json(snapshot());}
    if(route==='export'){
      const files=exportFiles(store.project,runTemplate);
      files['README.md']='# 在线交互演示导出\n\n来自离线规则演示，未调用真实模型、未执行 VASP。参数与专业协议需独立验证。\n\n'+files['README.md'];
      return new Response(zipSync(Object.fromEntries(Object.entries(files).map(([name,text])=>[name,strToU8(text)]))),{headers:{'Content-Type':'application/zip'}});
    }
    throw new Error('在线版未实现此操作，请使用本机完整版。');
  }catch(error){return json({error:error.message},400);}
}
