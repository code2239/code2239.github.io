import React,{useState,useEffect,useRef} from 'react';
import {Upload,FileText,Sparkles,ArrowRight,ArrowLeft,Check,Loader2,Square,ChevronDown,AlertCircle,Box,Terminal} from 'lucide-react';
import type {State,Project,Cost} from './types';
import {request,isShowcase} from './transport';

type Draft={token:string;project:Project;cost:Cost;checks:any[]};
export function PlannerContent({state,initialGoal='',onComplete,onClose}:{state:State;initialGoal?:string;onComplete:(s:State)=>void;onClose:()=>void}){
  const [goal,setGoal]=useState(initialGoal),[text,setText]=useState(''),[filename,setFilename]=useState(''),[current,setCurrent]=useState(true),[engine,setEngine]=useState(isShowcase?'demo':state.config.engine==='demo'?'codex':state.config.engine),[busy,setBusy]=useState(false),[progress,setProgress]=useState(''),[error,setError]=useState(''),[draft,setDraft]=useState<Draft|null>(null),[saving,setSaving]=useState(false);
  const [agents,setAgents]=useState<any[]>([]);const input=useRef<HTMLInputElement>(null),controller=useRef<AbortController|null>(null),bodyRef=useRef<HTMLDivElement>(null);
  useEffect(()=>{request('/api/agents').then(r=>r.json()).then(r=>setAgents(r.agents||[])).catch(()=>{});return()=>controller.current?.abort();},[]);
  useEffect(()=>{bodyRef.current?.scrollTo({top:0});},[draft]);
  async function upload(file:File){setError('');if(file.size>500000){setError('结构文件最多 500 KB。');return;}setFilename(file.name);setText(await file.text());setCurrent(false);setDraft(null);}
  async function generate(){
    if(!goal.trim()){setError('先告诉我，你希望计算什么？');return;}
    if(!current&&!text.trim()){setError('请上传结构文件，或选择当前结构。');return;}
    setBusy(true);setError('');setDraft(null);setProgress('正在读取并校验材料结构…');controller.current=new AbortController();
    try{
      const res=await request('/api/plan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({goal,useCurrent:current,text,name:filename,engine,revision:state.project.revision}),signal:controller.current.signal});
      if(!res.ok){const data=await res.json();throw new Error(data.error);}
      const reader=res.body!.getReader(),decoder=new TextDecoder();let buffer='';
      while(true){const {value,done}=await reader.read();if(done)break;buffer+=decoder.decode(value,{stream:true});let index;while((index=buffer.indexOf('\n\n'))>=0){const frame=buffer.slice(0,index);buffer=buffer.slice(index+2);const type=frame.match(/^event: (.+)$/m)?.[1],raw=frame.match(/^data: (.+)$/m)?.[1];if(!raw)continue;const data=JSON.parse(raw);if(type==='progress')setProgress(data.text);if(type==='result')setDraft(data);if(type==='error')throw new Error(data.error);}}
    }catch(e){setError((e as Error).name==='AbortError'?'已停止生成，当前方案未改变。':(e as Error).message);}finally{setBusy(false);controller.current=null;}
  }
  async function apply(){if(!draft)return;setSaving(true);setError('');try{const res=await request('/api/plan/apply',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:draft.token,revision:state.project.revision})});const data=await res.json();if(!res.ok)throw new Error(data.error);onComplete(data);}catch(e){setError((e as Error).message);}finally{setSaving(false);}}
  return <><div ref={bodyRef} className="modal-body planner-body">
    {!draft?<>
      <div className="planner-section-label"><span>1</span>选择材料结构</div>
      <div className="planner-structure-options"><button disabled={busy} className={`planner-current ${current?'chosen':''}`} onClick={()=>setCurrent(true)}><Box size={23}/><div><strong>使用当前结构</strong><small>{state.project.structure.formula} · {state.project.structure.atoms} 个原子</small></div>{current&&<Check size={17}/>}</button><button disabled={busy} className={`planner-current ${!current?'chosen':''}`} onClick={()=>input.current?.click()}><Upload size={22}/><div><strong>{filename||'上传新的结构文件'}</strong><small>{isShowcase?'POSCAR / P1 CIF · 最大 500 KB':'POSCAR / CIF · 最大 500 KB'}</small></div>{!current&&<Check size={17}/>}</button></div>
      <input type="file" ref={input} hidden accept=".cif,.vasp,.poscar,.txt,POSCAR,CONTCAR" onChange={e=>{if(e.target.files?.[0])upload(e.target.files[0]);}}/>
      {!current&&text&&<details><summary><FileText size={14}/>{filename} · 查看文件</summary><pre>{text.slice(0,5000)}</pre></details>}
      <div className="planner-section-label"><span>2</span>说说你希望得到什么</div>
      <textarea className="planner-goal" aria-label="计算需求" disabled={busy} value={goal} onChange={e=>setGoal(e.target.value)} placeholder="例如：先优化这个结构，然后计算能带和态密度。预算 50 元。"/>
      <div className="planner-examples">{['只优化结构','固定结构，计算单点能','优化后计算能带和态密度','设计声子计算方案'].map(q=><button disabled={busy} key={q} onClick={()=>setGoal(q)}>{q}</button>)}</div>
      <details className="planner-engine"><summary><Terminal size={14}/>规划引擎：{{codex:'Codex · 真实 Agent',claude:'Claude Code · 真实 Agent',demo:'离线模板演示 · 非模型'}[engine]}<ChevronDown size={13}/></summary><div className="planner-engine-options">{['codex','claude','demo'].map(id=><label key={id}><input type="radio" disabled={busy||(isShowcase&&id!=='demo')} checked={engine===id} onChange={()=>setEngine(id)}/><span>{{codex:'Codex',claude:'Claude Code',demo:'离线规则演示（不调用模型）'}[id]}</span>{id!=='demo'&&<small>{agents.find(a=>a.engine===id)?.installed?'已检测到运行时':'等待检测 / 未安装'}</small>}</label>)}</div></details>
      <p className="fineprint">{isShowcase&&'在线版仅支持 POSCAR 和完整有序的 P1 CIF，其他 CIF 请先转换为 POSCAR。本次规划使用离线规则，不调用模型；上传结构仅在浏览器处理。'}生成草案不会提交计算。使用真实 Agent 时，会发送本次结构、需求与已启用技能。完成后可以继续修改节点与依赖。</p>
      {busy&&<div className="planner-progress"><Loader2 size={18} className="spin"/><div><strong>{progress||'正在连接所选 Agent…'}</strong><p>首次响应可能需要 1–3 分钟。你可以停止，当前方案会保留。</p></div></div>}
    </>:<>
      <div className="planner-generated"><span><Sparkles size={18}/></span><div><h3>{draft.project.name}</h3><p>{draft.project.workflow?.source==='demo'?'由离线模板规则生成 · 未调用模型':`由 ${draft.project.workflow?.source} 生成 · 已检查图依赖`}</p></div></div>
      <p className="detail-description">{draft.project.workflow?.summary}</p>
      <p className="fineprint">结构：{draft.project.structure.name} · {draft.project.structure.formula} · {draft.project.structure.atoms} 个原子</p>
      {!!draft.project.structure.importNotes?.length&&<details><summary>结构解析说明</summary>{draft.project.structure.importNotes.map((note,i)=><p className="fineprint" key={i}>{note}</p>)}</details>}
      <div className="planner-task-list">{draft.project.workflow?.tasks.map((task,i)=><article key={task.id}><span>{String(i+1).padStart(2,'0')}</span><div><strong>{task.title}{task.kind==='custom'&&<small>执行器待接入</small>}</strong><p>{task.description}</p><small>依赖：{task.dependsOn.length?task.dependsOn.map(id=>draft.project.workflow?.tasks.find(t=>t.id===id)?.title||id).join('、'):'上传的结构'}</small></div></article>)}</div>
      {!!draft.project.workflow?.questions.length&&<div className="notice warm"><AlertCircle size={17}/><div><strong>这些事项还需要确认</strong>{draft.project.workflow.questions.map((q,i)=><p key={i}>{q}</p>)}</div></div>}
      <details><summary>查看科学假设与规划记录</summary>{draft.project.workflow?.assumptions.map((a,i)=><p className="fineprint" key={i}>{a}</p>)}<p className="fineprint">模型用量：{draft.project.planning?.usage?JSON.stringify(draft.project.planning.usage):'未提供 / 模板模式'}</p></details>
      <div className="notice"><Sparkles size={16}/><span>任务耗时待标定，暂不提供伪精确报价。采用后，可在各节点填写耗时，并添加步骤、调整连线或继续问 AI。</span></div>
    </>}
    {error&&<p className="form-error" role="alert">{error}</p>}
  </div><footer>{draft?<><button className="button secondary" disabled={saving} onClick={()=>{setDraft(null);setError('');}}><ArrowLeft size={14}/>调整需求</button><button className="button primary" disabled={saving} onClick={apply}>{saving?<Loader2 size={16} className="spin"/>:<Check size={16}/>}采用方案，进入编排</button></>:<><button className="button secondary" onClick={busy?()=>controller.current?.abort():onClose}>{busy?<><Square size={13}/>停止生成</>:'取消'}</button><button className="button primary" disabled={busy||!goal.trim()||(!current&&!text)} onClick={generate}>{busy?<Loader2 size={16} className="spin"/>:<Sparkles size={16}/>}生成计算方案<ArrowRight size={14}/></button></>}</footer></>;
}
