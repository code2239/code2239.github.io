/// <reference types="vite/client" />

export const isShowcase=import.meta.env.MODE==='showcase';
export const showcaseDownload=`${import.meta.env.BASE_URL}matterflow-local.zip`;

export async function request(input:string, init?:RequestInit):Promise<Response>{
  if(isShowcase){
    const {browserRequest}=await import('./showcase.mjs');
    return browserRequest(input,init);
  }
  return fetch(input,init);
}

export async function downloadInputs(){
  if(!isShowcase){window.location.href='/api/export';return;}
  const response=await request('/api/export');
  if(!response.ok)throw new Error((await response.json()).error);
  const url=URL.createObjectURL(await response.blob());
  const link=document.createElement('a');link.href=url;link.download='matterflow-inputs.zip';link.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}
