import type {Project,Task} from './types';
export const taskLabels:Record<string,string>={relax:'优化结构',scf:'静态自洽计算',bands:'生成能带',dos:'生成态密度',custom:'专业计算步骤'};
export function tasksOf(project:Project):Task[]{
  if(project.workflow)return project.workflow.tasks;
  return ['relax','scf','bands',...(project.includeDos?['dos']:[])].map(kind=>({id:kind,kind,title:taskLabels[kind],description:'常规 PBE 计算步骤',dependsOn:kind==='relax'?[]:kind==='scf'?['relax']:['scf'],estimatedHours:project.settings.hours[kind]}));
}
export function taskTitle(project:Project,id:string){return id==='structure'?'晶体结构':tasksOf(project).find(t=>t.id===id)?.title||id;}
