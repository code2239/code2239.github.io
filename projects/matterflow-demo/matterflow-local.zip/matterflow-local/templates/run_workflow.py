"""常规非磁性 PBE 工作流模板，需用户自己的 VASP、势库和资源分配。

没有自动提交集群。模板只支持与路径标准原胞一致的输入晶胞，避免混用坐标。
"""
from pathlib import Path
import argparse
import json
import os
import shlex
import shutil
import subprocess
import re

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.vasp import Incar, Poscar, Kpoints, Vasprun
from pymatgen.symmetry.bandstructure import HighSymmKpath
from assemble_potcar import assemble

ROOT = Path(__file__).resolve().parent
PLAN = json.loads((ROOT / "workflow.json").read_text())
CONFIG = PLAN["settings"]
SPEC = [s.strip() for s in (ROOT / "potcar.spec").read_text().splitlines() if s.strip()]


def checked_path(structure):
    path = HighSymmKpath(structure)
    if len(path.prim) != len(structure) or not np.allclose(
        path.prim.lattice.matrix, structure.lattice.matrix, atol=1e-5, rtol=1e-5
    ):
        raise RuntimeError(
            "输入晶胞与路径标准原胞不同。本模板不会混用路径坐标；"
            "请先明确并标准化原胞，然后重新生成、审阅整个流程。"
        )
    return path


def prepare(name, structure, previous=None, kind=None):
    kind = kind or name
    if not re.fullmatch(r"[a-z][a-z0-9_-]{0,39}", name):
        raise RuntimeError("无效的任务目录标识")
    folder = ROOT / "calculations" / name
    folder.mkdir(parents=True, exist_ok=True)
    structure = structure.get_sorted_structure()
    Poscar(structure).write_file(folder / "POSCAR")
    species = [str(s) for s in Poscar(structure).site_symbols]
    mapping = dict(zip(PLAN["structure"]["species"], SPEC))
    if len(mapping) != len(SPEC) or any(s not in mapping for s in species):
        raise RuntimeError("potcar.spec 元素数或顺序与输入结构不一致")
    assemble(folder / "POTCAR", [mapping[s] for s in species])
    incar = {
        "ENCUT": CONFIG["encut"], "EDIFF": 1e-6, "PREC": "Accurate",
        "GGA": "PE", "ISPIN": 1, "ISMEAR": 0, "SIGMA": 0.05,
        "LREAL": False, "LASPH": True, "LCHARG": True, "LWAVE": False,
        "LMAXMIX": 6, "NELM": 120,
    }
    mesh = [CONFIG["kmesh"]] * 3
    if kind == "relax":
        incar.update({"IBRION": 2, "ISIF": 3, "NSW": 150, "EDIFFG": -0.02})
    else:
        incar.update({"IBRION": -1, "NSW": 0})
    if kind in ("bands", "dos"):
        if previous is None or not (previous / "CHGCAR").is_file():
            raise RuntimeError("非自洽步骤需要已收敛 SCF 的 CHGCAR")
        shutil.copy2(previous / "CHGCAR", folder / "CHGCAR")
        incar.update({"ICHARG": 11, "ISYM": 0, "LCHARG": False})
        if kind == "bands":
            points, labels = checked_path(structure).get_kpoints(
                line_density=25, coords_are_cartesian=False
            )
            kpoints = Kpoints(
                comment="High symmetry path in the verified input cell",
                num_kpts=len(points), style=Kpoints.supported_modes.Reciprocal,
                kpts=points, kpts_weights=[1.0] * len(points), labels=labels,
            )
        else:
            mesh = [max(12, CONFIG["kmesh"])] * 3
            incar.update({"NEDOS": 2001})
            kpoints = Kpoints.gamma_automatic(mesh)
    else:
        kpoints = Kpoints.gamma_automatic(mesh)
    Incar(incar).write_file(folder / "INCAR")
    kpoints.write_file(folder / "KPOINTS")
    return folder


def execute(folder, kind=None):
    kind = kind or folder.name
    command = os.environ.get("VASP_COMMAND")
    if not command:
        raise RuntimeError("请设置 VASP_COMMAND，并在已有资源分配内运行")
    with (folder / "vasp.stdout").open("w") as log:
        subprocess.run(
            shlex.split(command), cwd=folder, check=True,
            stdout=log, stderr=subprocess.STDOUT,
        )
    result = Vasprun(folder / "vasprun.xml", parse_projected_eigen=False)
    if not result.converged_electronic or (
        kind == "relax" and not result.converged_ionic
    ):
        raise RuntimeError(f"{folder.name} 未通过收敛检查，已停止下游计算")
    return result.final_structure


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--prepare-only", action="store_true")
    group.add_argument("--run", action="store_true")
    args = parser.parse_args()
    structure = Structure.from_file(ROOT / "structure.vasp")
    workflow = PLAN.get("workflow")
    if not workflow or not workflow.get("tasks"):
        raise RuntimeError("缺少显式工作流，请从更新后的应用重新导出。")
    tasks = workflow["tasks"]
    if workflow.get("questions") or any(t["kind"] == "custom" for t in tasks):
        raise RuntimeError("此方案仍有待确认事项或缺失执行器，仅可规划，不能直接执行。")
    ids = [t["id"] for t in tasks]
    if len(set(ids)) != len(ids) or any(not re.fullmatch(r"[a-z][a-z0-9_-]{0,39}", i) for i in ids):
        raise RuntimeError("任务标识重复或无效。")
    completed, folders = {}, {}
    pending = list(tasks)
    if any(t["kind"] == "bands" for t in tasks):
        checked_path(structure)
    while pending:
        ready = [t for t in pending if all(i in completed for i in t["dependsOn"])]
        if args.prepare_only:
            roots = [t for t in tasks if not t["dependsOn"]]
            for task in roots:
                if task["kind"] not in ("relax", "scf"):
                    raise RuntimeError("非自洽任务不能缺少 SCF。")
                prepare(task["id"], structure, kind=task["kind"])
            print("已准备所有根任务输入；下游会在上游实际运行结束后生成。")
            return
        if not ready:
            raise RuntimeError("工作流有循环或缺失依赖，已停止。")
        for task in ready:
            if task["kind"] not in ("relax", "scf", "bands", "dos"):
                raise RuntimeError("未知执行器，已停止。")
            upstream = [t for t in tasks if t["id"] in task["dependsOn"]]
            if task["kind"] in ("bands", "dos"):
                parents = [t for t in upstream if t["kind"] == "scf"]
                if len(parents) != 1:
                    raise RuntimeError("性质任务需要唯一的 SCF 电荷密度来源。")
                parent = parents[0]["id"]
                folder = prepare(task["id"], completed[parent], folders[parent], kind=task["kind"])
            else:
                if len(upstream) > 1:
                    raise RuntimeError("结构来源不唯一，请明确上游结构。")
                source = completed[upstream[0]["id"]] if upstream else structure
                folder = prepare(task["id"], source, kind=task["kind"])
            completed[task["id"]] = execute(folder, task["kind"])
            folders[task["id"]] = folder
            pending.remove(task)
    print("流程已结束；请继续检查目标性质与数值收敛。")


if __name__ == "__main__":
    main()
