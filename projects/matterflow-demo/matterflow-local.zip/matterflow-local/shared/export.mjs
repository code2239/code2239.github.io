import { estimate, checks } from '../server/core.mjs';
import { workflowOf, validateWorkflow } from '../server/workflow.mjs';

export function exportFiles(project, runTemplate) {
  project={...project,workflow:validateWorkflow(workflowOf(project))};
  const s=project.settings;
  const blocked=project.workflow.tasks.filter(t=>t.kind==='custom').map(t=>`${t.title}：执行器待接入`);
  blocked.push(...project.workflow.questions);
  const initial=project.workflow.tasks.filter(t=>!t.dependsOn.length&&['relax','scf'].includes(t.kind));
  return {
    'workflow.json': JSON.stringify(project,null,2),
    'cost-estimate.json': JSON.stringify({ ...estimate(project), checks:checks(project), note:'人工示例估算；不是模型预测，不含排队、Agent 和存储费用。' },null,2),
    'structure.vasp': project.structure.text,
    'potcar.spec': project.structure.species.join('\n')+'\n',
    'requirements.txt': '# Validated with Python 3.12\npymatgen==2026.10.24\npymatgen-core==2026.10.16\n',
    'execution-readiness.json':JSON.stringify({executable:!blocked.length,blockedReasons:blocked,note:'导出不提交作业；有待确认事项或专业草案时运行器会拒绝执行。'},null,2),
    ...Object.fromEntries(initial.flatMap(t=>[
      [`inputs/${t.id}/POSCAR`,project.structure.text],
      [`inputs/${t.id}/KPOINTS`,`MatterFlow uniform mesh\n0\nGamma\n${s.kmesh} ${s.kmesh} ${s.kmesh}\n0 0 0\n`],
      [`inputs/${t.id}/INCAR`,`SYSTEM = MatterFlow ${t.kind} template\nGGA = PE\nISPIN = 1\nENCUT = ${s.encut}\nEDIFF = 1e-6\nEDIFFG = -0.02\nPREC = Accurate\nISMEAR = 0\nSIGMA = 0.05\nIBRION = ${t.kind==='relax'?2:-1}\nISIF = 3\nNSW = ${t.kind==='relax'?150:0}\nNELM = 120\nLREAL = .FALSE.\nLASPH = .TRUE.\nLCHARG = .TRUE.\nLWAVE = .FALSE.\nLMAXMIX = 6\n`],
      [`inputs/${t.id}/potcar.spec`,project.structure.species.join('\n')+'\n'],
    ])),
    'README.md': `# MatterFlow 导出包\n\n方案版本：${project.revision}\n目标：${project.goal}\n\n## 范围\n这是待验证的常规 PBE 模板；没有运行 VASP，也没有验证数值收敛。导出不会提交作业。复杂磁性、SOC、HSE 需另行制定协议。任务与依赖以 workflow.json 为准；execution-readiness.json 列出当前执行限制。\n\n## 在授权计算环境运行\n1. 安装 requirements.txt 中的依赖，记录并固定实际软件版本。\n2. 将 VASP_PP_PATH 指向含 Si/POTCAR 等元素子目录的授权 PBE 势库（多版本势库先选择同一版本根目录）。检查 potcar.spec 的势选择，必要时按研究协议修改。\n3. 设置 VASP_COMMAND 为你在已有资源分配内运行 VASP 的命令，如 srun vasp_std。\n4. python run_workflow.py --prepare-only 仅准备根任务输入并组装 POTCAR。\n5. python run_workflow.py --run 依次运行，后续步骤使用实际输出；本脚本不申请计算资源。\n\n四件套使用 pymatgen 生成；SCF 与非自洽输入须等待上游结构和 CHGCAR。运行每一步后检查电子/离子收敛，不通过则停止。只有已填写的耗时参与估价，待估算任务不会记作免费；示例费用不能当作该体系实测时间。\n`,
    'assemble_potcar.py': `"""在用户授权的本地 PBE 势库组装 POTCAR，不下载或生成新赝势。"""\nfrom pathlib import Path\nimport os\n\ndef assemble(target, symbols):\n    root = os.environ.get("VASP_PP_PATH")\n    if not root:\n        raise RuntimeError("请设置 VASP_PP_PATH 指向已获授权的同一版本 PBE 势库")\n    paths = [Path(root) / symbol / "POTCAR" for symbol in symbols]\n    for symbol, path in zip(symbols, paths):\n        if not path.is_file():\n            raise RuntimeError(f"缺少势文件：{symbol}，请核对 potcar.spec 与势库版本")\n        head = path.read_bytes()[:1000].decode(errors="replace")\n        if "PBE" not in head:\n            raise RuntimeError(f"{symbol} 势头未标识 PBE，请人工核查兼容性")\n    Path(target).write_bytes(b"".join(path.read_bytes() for path in paths))\n\nif __name__ == "__main__":\n    symbols = [s.strip() for s in Path("potcar.spec").read_text().splitlines() if s.strip()]\n    assemble("POTCAR", symbols)\n`,
    'run_workflow.py': runTemplate,
  };
}

