import {mkdir,readFile,readdir,writeFile,cp,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {zipSync,strToU8,unzipSync} from 'fflate';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const site=process.argv[2];
if(!site||!path.isAbsolute(site))throw new Error('请提供网站检出的绝对路径。');
const destination=path.join(site,'public/projects/matterflow-demo');
await mkdir(destination,{recursive:true});
await cp(path.join(root,'dist-showcase'),destination,{recursive:true});
// Explicit allowlist: never include local projects, credentials, runtimes or screenshots.
const allowed=['src','server','shared','templates','tests','scripts','package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html','README.md','SHOWCASE.md','requirements.txt','.gitignore','examples/Si.cif'];
const files={};
async function collect(relative){
  const absolute=path.join(root,relative);
  const {stat}=await import('node:fs/promises');
  if((await stat(absolute)).isDirectory()){
    for(const name of await readdir(absolute))if(!name.startsWith('.')&&!['__pycache__','node_modules'].includes(name))await collect(path.join(relative,name));
  }else files[`matterflow-local/${relative}`]=new Uint8Array(await readFile(absolute));
}
for(const item of allowed)await collect(item);
files['matterflow-local/开始使用.txt']=strToU8('MatterFlow 本机完整版\n\n需要 Node.js 20+。进入解压后的目录，依次执行：\nnpm ci\nnpm run build\nnpm start\n\n打开 http://127.0.0.1:4317/\n一般 CIF 解析另需 Python 与 pymatgen，详见 README.md。\n真实 Agent 需安装并配置自己的 Codex / Claude Code；本包不含账号、密钥、个人结构或计算记录。\n');
const zip=zipSync(files);
const names=Object.keys(unzipSync(zip));
if(names.some(name=>/(?:^|\/)(?:\.data|\.venv|\.env|auth\.json|node_modules)(?:\/|$)/.test(name)))throw new Error('下载包包含禁止发布的本机数据。');
await writeFile(path.join(destination,'matterflow-local.zip'),zip);
await cp(path.join(root,'examples/Si.cif'),path.join(destination,'Si.cif'));
console.log(JSON.stringify({destination,sourceFiles:names.length,zipBytes:zip.length}));
