# MatterFlow · 本机材料计算助手 Demo

一个中文材料计算工作台：默认简单、点击展开细节、随处问 AI。

## 启动

需要 Node.js 20+（本次验证使用 Node.js 26）。在本目录执行：

```bash
npm install
npm run dev
```

打开 http://127.0.0.1:4317 。开发热更新另使用本机 4318 端口。

也可以运行已构建的版本：

```bash
npm run build
npm start
```

服务仅监听 127.0.0.1。使用 `PORT` 可以更换应用端口。终端按 Ctrl+C 停止。

## 建议体验顺序

1. 点击“新建计算”，上传 POSCAR / CIF，描述计算需求，调用本机 Agent 生成方案；也可选择当前结构。
2. 查看草案中的步骤、科学假设与待确认事项，点击“采用方案，进入编排”。
3. 拖动节点、添加步骤、连线调整依赖；双击连线可以移除依赖。点击节点编辑参数、依赖和耗时，也可随时“问 AI”。
4. 点击费用卡片，修改核数、单价和预算；通过版本记录与撤销检查变化。
5. 导出 ZIP，检查初始 POSCAR、INCAR、KPOINTS，以及运行脚本和 POTCAR 组装说明。
6. 点击“预览运行”，查看明确标注的模拟进度、日志和示意结果。
7. 在“设置与专业能力”中切换 Agent，或添加、修改、启用专业技能。

## 实现范围

| 能力 | 当前状态 |
| --- | --- |
| 结构 + 需求 → Agent 规划 | 真实模型接口，草案预览后采用；已验证 Codex 生成单点方案 |
| React Flow 拖动、添加、移除节点、调整依赖 | 真实交互；服务端拒绝循环、缺失依赖及无效数据来源 |
| DOS 分支、参数、核时费用、版本、撤销 | 真实实现、服务端校验 |
| POSCAR 导入 | 正数缩放的 VASP 5 格式，完整坐标、最多 1000 原子 |
| CIF 导入 | P1 轻量解析，其余由本机 pymatgen 展开对称性；拒绝部分占位、多结构和超过 1000 原子 |
| 常驻助手 | 默认离线规则演示，始终标明“无模型调用” |
| Codex | 本机 CLI 程序化调用；已用公开 Si 示例验证真实回答 |
| Claude Code | 接口已实现，需 ANTHROPIC_API_KEY；当前环境未配置，未做真实调用验证 |
| Skill 页面 | SKILL.md 新建、编辑、文件导入、启用/禁用、本机持久化；内容注入模型上下文 |
| VASP 输入导出 | 初始模板及 pymatgen 运行脚本；后续步骤延迟绑定结构和 CHGCAR |
| HPC / VASP 执行 | 未接入。模拟回放不提交真实计算 |
| 能带结果 | 明确标注的示意图，不是 VASP 输出 |
| 时间、费用 | 新任务耗时为“待估算”，填写后按图计算关键路径和累计费用；不含排队、Agent、存储费用 |

新建计算默认选择真实 Agent；可展开“规划引擎”显式切换为离线规则演示。分别支持仅弛豫、固定结构单点、能带、态密度等流程。声子、弹性、NEB 等保留为专业草案节点与待确认事项，执行器尚未接入；导出运行器会阻止执行这类草案。

一般 CIF 解析需要 Python 3.12 环境。可在本目录创建 `.venv` 并安装 `requirements.txt`，或通过 `PYMATGEN_PYTHON` 指向已有 pymatgen 的 Python。本次已配置本机 `.venv`；POSCAR 不依赖 Python。

## Agent 配置

在“设置与专业能力 → Agent 管理”中选择引擎。检测认证与真正完成模型调用是分开的，页面不将检测结果当作调用成功。

- Codex：安装官方 CLI，先在本机完成 `codex login`，再启动此服务。可通过 `CODEX_BIN` 指定可执行文件。
- Claude Code：安装官方 CLI，并在服务端环境配置 `ANTHROPIC_API_KEY`；可通过 `CLAUDE_BIN` 指定可执行文件。此 Demo 不把 claude.ai 套餐登录作为第三方应用授权。
- 不可用时显示真实错误，不静默切换为演示助手。每轮最长约 150 秒，可点停止；首轮耗时受网络、默认模型和运行时启动影响。

本次已验证真实 Codex 问答，以及上传 Si CIF 后生成固定结构单点方案（约 129 秒）；未指定或替换用户默认模型。真实回答不意味着计算结果得到科学验证。

规划 Agent 收到本次上传结构、需求和已启用的 Skill 内容；聊天 Agent 收到项目摘要、最近最多六条对话和已启用的 Skill 内容。Codex 在只读沙箱中运行并关闭 shell、多 Agent、浏览器、插件等相关能力；Claude 配置为空工具集。模型只返回回答与允许的修改建议，真正修改仍由应用校验。此版本不向模型提供集群凭据，也不允许模型直接提交计算。

这是单用户本机 demo，不是可直接暴露到公网的服务。不要把包含密钥、原始 POTCAR 或其他受限内容的材料放入 Skill 文本或聊天。

## 数据与技能

项目、修改历史、消息与回放记录保存在 `.data/state.json`。通过页面保存的技能另写入 `.data/skills/<id>/SKILL.md`。不改写用户全局 Codex/Claude 配置，也不自动执行技能脚本。

当前采用受控文本注入，不是两个引擎原生 Skill 自动发现的完整兼容实现。只检查元数据与文件大小，不宣称已通过科学审核。

## 导出包

参考 `examples/si-inputs.zip`，或从界面导出当前方案：

```text
workflow.json
cost-estimate.json
execution-readiness.json
structure.vasp
inputs/relax/POSCAR
inputs/relax/INCAR
inputs/relax/KPOINTS
inputs/relax/potcar.spec
potcar.spec
assemble_potcar.py
run_workflow.py
requirements.txt
README.md
```

没有分发 VASP 或 POTCAR。运行脚本前需在用户自己的授权计算环境安装 Python 依赖、核对势选择并设置 `VASP_PP_PATH` 与 `VASP_COMMAND`。脚本不申请集群资源。POTCAR 由本地授权 PBE 势库组装；缺失时停止。

脚本对输入晶胞与标准原胞的高对称路径一致性做前置检查；不匹配则拒绝继续，避免错误使用路径坐标。只支持常规非磁性 PBE 模板；HSE、SOC、磁性、无序结构等需另行实现并审核协议。运行时检查电子和离子收敛，但目标性质、截断能和 k 点精度仍需独立验证。

导出根节点输入以实际任务 ID 命名，仅单点方案不会生成弛豫输入。运行脚本按 workflow.json 依赖执行选择的任务。

界面按资源允许并行的任务估算关键路径，当前导出脚本为顺序执行，实际总时间可能更长；费用按所有任务累计。修改 ENCUT/k 点不会凭空推断新耗时，需更新估算或重新标定。

## 验证

```bash
npm test
npm run build
```

隔离 API 验证（避免修改日常演示项目）：

```bash
PORT=4319 MATTERFLOW_DATA_DIR=/tmp/matterflow-qa node server/index.mjs
# 另一个终端
node tests/api-smoke.mjs
node tests/plan-smoke.mjs
# 会产生模型调用用量，按需手动运行：
node tests/agent-smoke.mjs
node tests/plan-smoke.mjs --real
```

Python 输入验证：将导出包解压，在安装其 requirements.txt 的环境运行：

```bash
python tests/validate_export.py /absolute/path/to/unpacked-export
```

该检查用测试占位文件替代 PAW 组装边界，只验证输入、依赖与路径处理，不运行 VASP 或使用真实势库。

本次验证通过：19 项核心与工作流测试、API 成功/失败回放与状态校验、真实 Codex 回答和结构驱动规划，以及 pymatgen 对结构/INCAR/KPOINTS 的读写、CHGCAR 依赖和晶胞路径一致性检查。已在浏览器验证节点详情、预算、助手建议应用、技能页和结果页。

## 目录

- `src/`：React 界面与样式。
- `server/core.mjs`：工作流、结构解析、校验、费用和演示助手。
- `server/agents.mjs`：本机 Agent 适配器。
- `server/index.mjs`：本机 API、持久化和回放。
- `server/export.mjs`、`templates/`：ZIP 与 Python 工作流生成。
- `tests/`：核心、接口和输入验证。

完整前期设计见上级目录的可行性报告、Agent／Skill 设计与产品优化路线图。
