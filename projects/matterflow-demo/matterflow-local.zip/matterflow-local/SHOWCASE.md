# MatterFlow 在线交互演示

在线版复用本机版的 React Flow 界面、任务图校验、成本核算、输入包生成与结构解析。

```bash
npm ci
npm run build:showcase
```

`dist-showcase/` 是可部署在 GitHub Pages 的静态产物，默认路径 `/projects/matterflow-demo/`。不需要也不提供在线 Node / Python 服务。

在线状态通过浏览器 localStorage 保存；新访客从公开的 Si 示例开始。支持 POSCAR / 完整有序的 P1 CIF，非 P1 CIF 请在本机版使用 pymatgen 解析。页面上传的结构、对话和技能不发送到后端。

在线规划与助手仅为明确标记的离线规则演示，不调用模型，不自动执行专业 Skill。Codex / Claude Code 只能通过下载的本机版连接。模拟回放与曲线均非真实计算结果，专业步骤未接入执行器时导出运行器会拒绝执行。

在网站检出中复制产物并生成经过白名单筛选的本机源码 ZIP：

```bash
node scripts/package-showcase.mjs /absolute/path/to/website-checkout
```

脚本仅打包源码、公开结构样例与依赖清单，不包含 `.data`、`.venv`、凭据、私人结构、会话或本机截图。首次运行本机版仍需自行安装依赖与配置 Agent。
